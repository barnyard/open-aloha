/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.samples;

import java.net.URI;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bt.aloha.media.conference.event.ConferenceActiveEvent;
import com.bt.aloha.media.conference.event.ConferenceEndedEvent;
import com.bt.aloha.media.conference.event.ParticipantConnectedEvent;
import com.bt.aloha.media.conference.event.ParticipantDisconnectedEvent;
import com.bt.aloha.media.conference.event.ParticipantFailedEvent;
import com.bt.aloha.media.conference.event.ParticipantTerminatedEvent;
import com.bt.aloha.media.convedia.conference.ConferenceBean;
import com.bt.aloha.media.convedia.conference.ConferenceListener;

/**
 * ConferenceCall with the addition of being a "listener" to events related to calls
 */
public class ConferenceCall implements ConferenceListener {

    private ClassPathXmlApplicationContext applicationContext;
    private String conferenceId;
    private String[] callees;

    public void makeCall(String[] callees) throws Exception {
        this.callees = callees;

        // load Spring
        applicationContext = new ClassPathXmlApplicationContext("com/bt/aloha/samples/ConferenceCall.ApplicationContext.xml");

        // get required beans
        ConferenceBean conferenceBean = (ConferenceBean) applicationContext.getBean("conferenceBean");

        // make this class a listener to call events
        conferenceBean.addConferenceListener(this);

        // create the conference
        this.conferenceId = conferenceBean.createConference();
        System.out.println("conferenceId: " + this.conferenceId);

        for (String callee : this.callees) {
            // create call legs and invite to conference
            String callLegId = conferenceBean.createParticipantCallLeg(this.conferenceId, URI.create(callee));
            System.out.println("Call Leg Id: " + callLegId);
            conferenceBean.inviteParticipant(this.conferenceId, callLegId);
        }
    }

    public void onConferenceActive(ConferenceActiveEvent arg0) {
        System.out.println(arg0.getClass().getSimpleName());
    }

    public void onConferenceEnded(ConferenceEndedEvent arg0) {
        System.out.println(arg0.getClass().getSimpleName());
        if (arg0.getConferenceId().equals(this.conferenceId))
            this.applicationContext.destroy();
    }

    public void onParticipantConnected(ParticipantConnectedEvent arg0) {
        if (arg0.getConferenceId().equals(this.conferenceId)) {
            System.out.println(String.format("%s participant id: %s",
                    arg0.getClass().getSimpleName(),
                    arg0.getDialogId()));
        }
    }

    public void onParticipantDisconnected(ParticipantDisconnectedEvent arg0) {
        if (arg0.getConferenceId().equals(this.conferenceId)) {
            System.out.println(String.format("%s participant id: %s",
                    arg0.getClass().getSimpleName(),
                    arg0.getDialogId()));
        }
    }

    public void onParticipantFailed(ParticipantFailedEvent arg0) {
        System.out.println(String.format("%s: conference Id: %s, participant Id: %s",
                arg0.getClass().getSimpleName(),
                arg0.getConferenceId(),
                arg0.getDialogId()));
        this.applicationContext.destroy();
    }

    public void onParticipantTerminated(ParticipantTerminatedEvent arg0) {
        if (arg0.getConferenceId().equals(this.conferenceId)) {
            System.out.println(String.format("%s participant id: %s",
                    arg0.getClass().getSimpleName(),
                    arg0.getDialogId()));
        }
    }

    public static void main(String[] args) throws Exception {
        new ConferenceCall().makeCall(new String[] { "sip:01442208294@10.238.67.22",
                "sip:07917024142@10.238.67.22" });
    }
}
