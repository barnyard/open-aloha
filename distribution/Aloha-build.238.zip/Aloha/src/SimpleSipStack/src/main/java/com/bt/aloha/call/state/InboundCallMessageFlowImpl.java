/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call.state;

import javax.sdp.MediaDescription;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.dialog.state.ImmutableDialogInfo;

public class InboundCallMessageFlowImpl extends DefaultCallMessageFlowImpl {
	private static final Log LOG = LogFactory.getLog(InboundCallMessageFlowImpl.class);
	
	public InboundCallMessageFlowImpl() {
	}

	/**
	 * This overload is necessary to specify the suppressproxy parameter. that parameter makes sure we only 
	 * proxy initial invite when joining calls, not when one of them has connected (at that point we've lost the offer media)
	 */
	@Override
	public MediaNegotiationCommand initializeCall(ImmutableDialogInfo firstDialogInfo, ImmutableDialogInfo secondDialogInfo, ReadOnlyCallInfo callInfo, MediaDescription offerMediaDescription) {
		return initializeCall(firstDialogInfo, secondDialogInfo, callInfo, offerMediaDescription, false);
	}
	
	protected MediaNegotiationCommand initializeCall(ImmutableDialogInfo firstDialogInfo, ImmutableDialogInfo secondDialogInfo, ReadOnlyCallInfo callInfo, MediaDescription offerMediaDescription, boolean suppressProxy) {		
		LOG.debug(String.format("Initializing call %s using sip flow %s", callInfo.getId(), this.getClass().getSimpleName()));
		ImmutableDialogInfo inboundDialogInfo = firstDialogInfo.isInbound() ? firstDialogInfo : secondDialogInfo;
		ImmutableDialogInfo outboundDialogInfo = firstDialogInfo.isInbound() ? secondDialogInfo : firstDialogInfo;
    	
    	CallLegConnectionState inboundConnectionState = callInfo.getCallLegConnectionState(inboundDialogInfo.getId());
    	CallLegConnectionState outboundConnectionState = callInfo.getCallLegConnectionState(outboundDialogInfo.getId());
    	
    	MediaNegotiationCommand command = null;
    	if (callInfo.areBothCallLegsConnected())
    		command = new InitiateMediaNegotiationCommand(inboundDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), inboundConnectionState);
    	else if (outboundConnectionState.equals(CallLegConnectionState.Pending) || outboundConnectionState.equals(CallLegConnectionState.Completed)) { 
    		if (inboundDialogInfo.isSdpInInitialInvite() && inboundConnectionState.equals(CallLegConnectionState.Pending)) {
    			command = new ProxyMediaOfferCommand(outboundDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), offerMediaDescription, outboundConnectionState, true);    		
    		} else if (inboundConnectionState.equals(CallLegConnectionState.Pending) || inboundConnectionState.equals(CallLegConnectionState.Completed)) {				
    			command = new InitiateMediaNegotiationCommand(outboundDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), outboundConnectionState);
    		}
    	}
    	
    	return command;
	}
	
	@Override
	public MediaNegotiationCommand processCallLegConnected(ImmutableDialogInfo eventDialogInfo, ImmutableDialogInfo otherDialogInfo, ReadOnlyCallInfo callInfo, boolean refreshOriginatedByCurrentCall, MediaDescription mediaDescription) {
		LOG.debug(String.format("Processing call leg connected event for call leg %s in call %s using sip flow %s, refresh originated by call is %s, media neg state is %s", eventDialogInfo.getId(), callInfo.getId(), this.getClass().getSimpleName(), refreshOriginatedByCurrentCall, callInfo.getMediaNegotiationState()));
    	InboundCallInfo inboundCallInfo;
    	if (callInfo instanceof InboundCallInfo)
    		inboundCallInfo = (InboundCallInfo)callInfo;
    	else
    		throw new ClassCastException("Expected an Inbound call info for inbound sip message flow!");
    	
    	MediaNegotiationCommand command = null;
    	if (refreshOriginatedByCurrentCall) {
    		command = super.processCallLegConnectedRefreshOriginatedByCurrentCall(eventDialogInfo, otherDialogInfo, callInfo, refreshOriginatedByCurrentCall, mediaDescription);
    	} else if (inboundCallInfo.getMediaNegotiationState().equals(MediaNegotiationState.Pending)) {
    		LOG.debug(String.format("Call leg connected event for dialog %s with state %s NOT originated by current call", eventDialogInfo.getId(), callInfo.getCallLegConnectionState(eventDialogInfo.getId())));
    		ImmutableDialogInfo firstDialogInfo = eventDialogInfo.getId().equals(callInfo.getFirstDialogId()) ? eventDialogInfo : otherDialogInfo;
	    	ImmutableDialogInfo secondDialogInfo = eventDialogInfo.getId().equals(callInfo.getSecondDialogId()) ? eventDialogInfo : otherDialogInfo;
	    	
	    	LOG.debug(String.format("Initiating media negotiation for call %s after connect - first leg is %s, second leg is %s", callInfo.getId(), firstDialogInfo.getId(), secondDialogInfo.getId()));	    	
	    	return initializeCall(firstDialogInfo, secondDialogInfo, callInfo, null, true);
    	}
    	return command;
	}
}
