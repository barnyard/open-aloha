/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call;

import java.util.Calendar;

import com.bt.aloha.call.state.CallLegCausingTermination;
import com.bt.aloha.call.state.CallState;
import com.bt.aloha.call.state.CallTerminationCause;

/**
 * Information about a call.
 */
public class CallInformation {
	private CallState callState;
	private Calendar startTime;
	private long duration;
	private CallTerminationCause callTerminationCause;
	private CallLegCausingTermination callLegCausingTermination;
	private String firstCallLegId;
	private String secondCallLegId;

	/**
     * Constructor
     * @param aCallState call state
     * @param aStartTime the start time of the call
     * @param aDuration the duration of the call
     * @param aCallTerminationCause the termination cause of the call
     * @param aCallLegCausingTermination the call leg that caused call termination
     * @param aFirstCallLegId the call leg id of the first call leg
     * @param aSecondCallLegId the call leg id of the second call leg
     */
    public CallInformation(CallState aCallState, long aStartTime, long aDuration, CallTerminationCause aCallTerminationCause, CallLegCausingTermination aCallLegCausingTermination, String aFirstCallLegId, String aSecondCallLegId) {
		this.callState = aCallState;
		this.startTime = Calendar.getInstance();
		this.startTime.setTimeInMillis(aStartTime);
		this.duration = aDuration;
		this.callTerminationCause = aCallTerminationCause;
		this.callLegCausingTermination = aCallLegCausingTermination;
		this.firstCallLegId = aFirstCallLegId;
		this.secondCallLegId = aSecondCallLegId;
	}

	/**
     * get the call state
     * @return the call state
	 */
    public CallState getCallState() {
		return callState;
	}

    /**
     * get the call start time
     * @return the call start time
     */
	public Calendar getStartTime() {
		return startTime;
	}

    /**
     * get the call duration
     * @return the call duration in seconds
     */
	public long getDuration() {
		return duration;
	}

	/**
     * get the call termination cause
     * @return the call termination cause
	 */
    public CallTerminationCause getCallTerminationCause() {
		return callTerminationCause;
	}

	/**
     * get the call leg that caused the termination
     * @return the call leg that caused the termination
	 */
    public CallLegCausingTermination getCallLegCausingTermination() {
		return callLegCausingTermination;
	}

	/**
	 * get the Call Leg Id of the first call leg
	 * @return the id
	 */
    public String getFirstCallLegId() {
		return firstCallLegId;
	}

	/**
	 * get the Call Leg Id of the second call leg
	 * @return the id
	 */
	public String getSecondCallLegId() {
		return secondCallLegId;
	}
}
