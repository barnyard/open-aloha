/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia.msml.model;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.bt.aloha.media.PromptAndRecordCommand;

public class MsmlPromptAndRecordRequestTest {

    @Test(expected=IllegalArgumentException.class)
    public void testConstructorTargetAddressNull() {
        PromptAndRecordCommand promptAndRecordCommand = new PromptAndRecordCommand("uri", true, "dest", false, "format", 10, 1, 1, null);
        new MsmlPromptAndRecordRequest(null, promptAndRecordCommand);
    }

    @Test(expected=IllegalArgumentException.class)
    public void testConstructorPromptAndRecordCommandNull() {
        new MsmlPromptAndRecordRequest("fred", null);
    }

    // test the construction of the xml with a null termination key
    @Test
    public void testGetXmlNullTerminationKey() {
        PromptAndRecordCommand promptAndRecordCommand = new PromptAndRecordCommand("file://uri", true, "file://dest", false, "audio/wav", 10, 1, 2, null);
        MsmlPromptAndRecordRequest request = new MsmlPromptAndRecordRequest("fred", "myCommandId", promptAndRecordCommand);
        String xml = request.getXml();
        assertXml(xml);
    }

    private void assertXml(String xml) {
        System.out.println(xml);
        assertTrue(xml.contains("<audio uri=\"file://uri\"/>"));
        assertTrue(xml.contains("<record dest=\"file://dest\""));
        assertTrue(xml.contains("format=\"audio/wav\""));
        assertTrue(xml.contains("append=\"false\""));
        assertTrue(xml.contains("maxtime=\"10s\""));
        assertTrue(xml.contains("cvd:pre-speech=\"1s\""));
        assertTrue(xml.contains("cvd:post-speech=\"2s\""));
        assertTrue(xml.contains("event=\"app.recordPlayCommandComplete\" namelist=\"record.recordid record.len record.end\""));
    }

    // test the construction of the xml with a termination key
    @Test
    public void testGetXmlWithTerminationKey() {
        PromptAndRecordCommand promptAndRecordCommand = new PromptAndRecordCommand("file://uri", true, "file://dest", false, "audio/wav", 10, 1, 2, '3');
        MsmlPromptAndRecordRequest request = new MsmlPromptAndRecordRequest("fred", "myCommandId", promptAndRecordCommand);
        String xml = request.getXml();
        assertXml(xml);
        assertTrue(xml.contains("cvd:termkey=\"3\""));
    }
}
