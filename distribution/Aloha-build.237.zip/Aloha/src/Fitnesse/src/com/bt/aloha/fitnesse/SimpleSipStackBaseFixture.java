/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse;

import java.net.URI;

import org.springframework.context.ApplicationContext;

import com.bt.aloha.call.CallBean;
import com.bt.aloha.call.CallBeanImpl;
import com.bt.aloha.call.collections.CallCollection;
import com.bt.aloha.callleg.OutboundCallLegBean;
import com.bt.aloha.callleg.OutboundCallLegBeanImpl;
import com.bt.aloha.dialog.DialogJainSipListener;
import com.bt.aloha.dialog.collections.DialogCollection;
import com.bt.aloha.media.DtmfCollectCommand;
import com.bt.aloha.phones.SipulatorPhone;

import fit.Fixture;

public abstract class SimpleSipStackBaseFixture extends Fixture {

	protected ApplicationContext applicationContext;
	protected String ipAddressPattern = "127.0.0.1";

    protected int firstDialogCallAnswerTimeout = 0;
	protected int secondDialogCallAnswerTimeout = 0;

    protected OutboundCallLegBean outboundCallLegBean;
	protected CallBean callBean;
	protected DialogJainSipListener dialogSipListener;
	private CallCollection callCollection;
	private DialogCollection dialogCollection;

	protected String firstPhoneUri;
	protected String secondPhoneUri;
	protected String thirdPhoneUri;

	protected String firstDialogId;
	protected String secondDialogId;
	protected String thirdDialogId;

    protected int waitTimeoutSeconds;

    static{
		FixtureApplicationContexts.getInstance().startMockphonesApplicationContext();
	}

    public SimpleSipStackBaseFixture(ApplicationContext applicationContext) {
    	super();
    	this.applicationContext = applicationContext;

        outboundCallLegBean = (OutboundCallLegBean)applicationContext.getBean("outboundCallLegBean");
    	callBean = (CallBean)applicationContext.getBean("callBean");
    	dialogSipListener = (DialogJainSipListener)applicationContext.getBean("dialogSipListener");
    	callCollection = (CallCollection)applicationContext.getBean("callCollection");
    	dialogCollection = (DialogCollection)applicationContext.getBean("dialogCollection");
    	
    	((CallBeanImpl)callBean).setCallCollection(getCallCollection());
		((CallBeanImpl)callBean).setDialogCollection(getDialogCollection());
		((OutboundCallLegBeanImpl)outboundCallLegBean).setDialogCollection(getDialogCollection());
		dialogSipListener.setDialogCollection(getDialogCollection());
    }

    protected CallCollection getCallCollection() {
		return callCollection;
	}

	protected DialogCollection getDialogCollection() {
		return dialogCollection;
	}

	public void ipAddressPattern(String ipAddressPattern) {
		this.ipAddressPattern = ipAddressPattern;
	}

    public void waitTimeoutSeconds(int seconds) {
    	this.waitTimeoutSeconds = seconds;
    }

    public void waitSeconds(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException e) {
        }
    }

    public void waitMilliSeconds(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
        }
    }

    public void firstDialogCallAnswerTimeout(int timeout) {
		this.firstDialogCallAnswerTimeout = timeout;
	}

	public void secondDialogCallAnswerTimeout(int timeout) {
		this.secondDialogCallAnswerTimeout = timeout;
	}

    public void firstPhoneUri(String firstPhone) {
		this.firstPhoneUri = getAddressAndPort(firstPhone);
	}

	public void secondPhoneUri(String secondPhone) {
		this.secondPhoneUri = getAddressAndPort(secondPhone);
	}

	public void thirdPhoneUri(String thirdPhone) {
		this.thirdPhoneUri = getAddressAndPort(thirdPhone);
	}

	public String createFirstDialog() {
		firstDialogId = outboundCallLegBean.createCallLeg(URI.create(secondPhoneUri), URI.create(firstPhoneUri), firstDialogCallAnswerTimeout);
		return "OK";
	}

	public String createSecondDialog() {
		secondDialogId = outboundCallLegBean.createCallLeg(URI.create(firstPhoneUri), URI.create(secondPhoneUri), secondDialogCallAnswerTimeout);
		return "OK";
	}

	public String createThirdDialog() {
		thirdDialogId = outboundCallLegBean.createCallLeg(URI.create(firstPhoneUri), URI.create(thirdPhoneUri));
		return "OK";
	}

	protected String getAddressAndPort(String address) {
		if (address == null)
			return null;

		String name = "";
		if (address.startsWith("sip:"))
			name = address.substring(0, address.indexOf("@")+1);

		if(address.indexOf(":", 5) > -1) {
			String ipAddress = address.substring(name.length(), address.lastIndexOf(":"));
			String port = address.substring(address.lastIndexOf(":"));
			return name + SipulatorPhone.lookupIpAddress(ipAddress) + port;
		} else {
			String ipAddress = address.substring(name.length(), address.length());
            System.out.println("returning " + name + SipulatorPhone.lookupIpAddress(ipAddress));
			return name + SipulatorPhone.lookupIpAddress(ipAddress);
		}
	}

    protected DtmfCollectCommand getDtmfCollectCommandWithMinMaxNumberOfDigitsAndReturnKey(String dtmfCollectCommandString, String audioFileUri) {
        String[] commandElements = dtmfCollectCommandString.split(",");
        Character cancelKey = null;
        if (commandElements.length > 8)
            cancelKey = new Character(commandElements[8].charAt(0));
        return new DtmfCollectCommand(
                audioFileUri,
                commandElements[0].toLowerCase().equals("true"),    // barge
                commandElements[1].toLowerCase().equals("true"),    // clear buffer
                Integer.parseInt(commandElements[2]),               // first digit timeout
                Integer.parseInt(commandElements[3]),               // inter digit timeout
                Integer.parseInt(commandElements[4]),               // last digit timeout
                Integer.parseInt(commandElements[5]),               // min number of digits
                Integer.parseInt(commandElements[6]),               // max number of digits
                commandElements[7].charAt(0),                       // return key
                cancelKey);
    }
}
