/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Vector;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import javax.sip.ResponseEvent;
import javax.sip.SipFactory;
import javax.sip.message.Response;

import org.easymock.classextension.EasyMock;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.bt.aloha.callleg.event.AbstractCallLegEvent;
import com.bt.aloha.callleg.event.CallLegConnectedEvent;
import com.bt.aloha.callleg.event.CallLegConnectionFailedEvent;
import com.bt.aloha.callleg.event.CallLegDisconnectedEvent;
import com.bt.aloha.callleg.event.CallLegRefreshCompletedEvent;
import com.bt.aloha.callleg.event.CallLegTerminatedEvent;
import com.bt.aloha.callleg.event.CallLegTerminationFailedEvent;
import com.bt.aloha.callleg.event.ReceivedCallLegRefreshEvent;
import com.bt.aloha.media.MediaCallLegListener;
import com.bt.aloha.media.event.callleg.CallLegAnnouncementCompletedEvent;
import com.bt.aloha.media.event.callleg.CallLegAnnouncementFailedEvent;
import com.bt.aloha.media.event.callleg.CallLegAnnouncementTerminatedEvent;
import com.bt.aloha.media.event.callleg.CallLegDtmfGenerationCompletedEvent;
import com.bt.aloha.media.event.callleg.CallLegDtmfGenerationFailedEvent;
import com.bt.aloha.media.event.callleg.CallLegPromptAndCollectDigitsCompletedEvent;
import com.bt.aloha.media.event.callleg.CallLegPromptAndCollectDigitsFailedEvent;
import com.bt.aloha.media.event.callleg.CallLegPromptAndCollectDigitsTerminatedEvent;
import com.bt.aloha.media.event.callleg.CallLegPromptAndRecordCompletedEvent;
import com.bt.aloha.media.event.callleg.CallLegPromptAndRecordFailedEvent;
import com.bt.aloha.media.event.callleg.CallLegPromptAndRecordTerminatedEvent;

public class MediaDialogSipBeanImplTest extends ConvediaMediaPerClassTestCase implements MediaCallLegListener {

	private List<AbstractCallLegEvent> receivedCallLegEvents;
    private Semaphore receivedCallLegDisconnectedSemaphore;

	@Before
	public void setup(){
		receivedCallLegEvents = new Vector<AbstractCallLegEvent>();
        receivedCallLegDisconnectedSemaphore = new Semaphore(0);
        mediaCallLegBean = (MediaCallLegBeanImpl)getApplicationContext().getBean("mediaCallLegBean");
        mediaCallLegBean.addMediaCallLegListener(this);
	}

    @After
    public void after() {
        mediaCallLegBean.removeMediaCallLegListener(this);
    }

	@Test
	public void testInfoOKTriggersNoEvent() throws Exception {
		// setup
		String callLegId = outboundCallLegBean.createCallLeg(getSecondInboundPhoneSipUri(), getInboundPhoneSipUri(), 0);
		String mediaCallLegId = mediaCallLegBean.createMediaCallLeg(callLegId);

		Response response = SipFactory.getInstance().createMessageFactory().createResponse(createInfoOkResponseString(mediaCallLegId));
		ResponseEvent responseEvent = EasyMock.createNiceMock(ResponseEvent.class);
        EasyMock.expect(responseEvent.getResponse()).andStubReturn(response);
		EasyMock.replay(responseEvent);

		// act
		((MediaCallLegBeanImpl)mediaCallLegBean).processResponse(responseEvent, dialogCollection.get(mediaCallLegId));
		// assert
		assertEquals(0, receivedCallLegEvents.size());
	}

    @Test
	public void testInfo481TriggersDialogDisconnectedEvent() throws Exception {
		// setup
		final String dialogId = outboundCallLegBean.createCallLeg(getSecondInboundPhoneSipUri(), getInboundPhoneSipUri(), 0);
		Response response = SipFactory.getInstance().createMessageFactory().createResponse(createInfo481ResponseString(dialogId));
		ResponseEvent responseEvent = EasyMock.createNiceMock(ResponseEvent.class);
        EasyMock.expect(responseEvent.getResponse()).andStubReturn(response);
		EasyMock.replay(responseEvent);
		// act
		((MediaCallLegBeanImpl)mediaCallLegBean).processResponse(responseEvent, dialogCollection.get(dialogId));

		// assert
        receivedCallLegDisconnectedSemaphore.tryAcquire(10, TimeUnit.SECONDS);
		assertEquals(1, receivedCallLegEvents.size());
		assertTrue(receivedCallLegEvents.get(0) instanceof CallLegDisconnectedEvent);
	}

    public void onCallLegAnnouncementCompleted(CallLegAnnouncementCompletedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegAnnouncementFailed(CallLegAnnouncementFailedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegAnnouncementTerminated(CallLegAnnouncementTerminatedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegDtmfGenerationCompleted(CallLegDtmfGenerationCompletedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegDtmfGenerationFailed(CallLegDtmfGenerationFailedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegPromptAndCollectDigitsCompleted(CallLegPromptAndCollectDigitsCompletedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegPromptAndCollectDigitsFailed(CallLegPromptAndCollectDigitsFailedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegPromptAndCollectDigitsTerminated(CallLegPromptAndCollectDigitsTerminatedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegPromptAndRecordCompleted(CallLegPromptAndRecordCompletedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegPromptAndRecordFailed(CallLegPromptAndRecordFailedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegPromptAndRecordTerminated(CallLegPromptAndRecordTerminatedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegConnected(CallLegConnectedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegConnectionFailed(CallLegConnectionFailedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegDisconnected(CallLegDisconnectedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
        receivedCallLegDisconnectedSemaphore.release();
    }

    public void onCallLegRefreshCompleted(CallLegRefreshCompletedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegTerminated(CallLegTerminatedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onCallLegTerminationFailed(CallLegTerminationFailedEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }

    public void onReceivedCallLegRefresh(ReceivedCallLegRefreshEvent arg0) {
        this.receivedCallLegEvents.add(arg0);
    }
}
