-- login as postgres user (administrator) and run the following
DROP DATABASE springring;
DROP ROLE springringuser;

