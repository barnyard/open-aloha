/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.phones;

import java.util.HashMap;

public class Controller {
    private static Controller theInstance = new Controller();
    private static HashMap<String, SipulatorPhone> phones = new HashMap<String, SipulatorPhone>();
    
    private Controller() {}
    
    public synchronized static Controller getInstance() {
        return theInstance;
    }

    public synchronized void createPhone(String name, String ipAddressPattern, String remoteSipAddress, String remoteSipProxy) throws Exception {
        SipulatorPhone phone = new SipulatorPhone(name, ipAddressPattern, remoteSipAddress, remoteSipProxy);
        phones.put(name, phone);
    }
    
    public synchronized boolean initiateCall(String name) throws Exception {
    	return initiateCall(name, null, null, null);
    }

    public boolean initiateCall(String name, String realm, String username, String password) {
        SipulatorPhone phone = phones.get(name);
       	phone.setCredentials(realm, username, password);
       	phone.start();
        return phone.initiateOutgoingCall();
	}
    
    public synchronized boolean sendInviteOkAck(String name) {
    	return phones.get(name).sendInviteOkAck();
	}
    
    public synchronized boolean respondToBye(String name) {
    	return phones.get(name).respondToBye();
	}
    
    public synchronized boolean waitResponse(String name, int responseCode, long waitTimeout) throws Exception {
        return phones.get(name).waitForResponse(responseCode, waitTimeout);
    }

	public boolean waitAnswer(String name, int responseCode, long waitTimeout) {
		return phones.get(name).waitAnswer(responseCode, waitTimeout);
	}

	public synchronized boolean waitForBye(String name, long waitTimeout) throws Exception {
        return phones.get(name).waitForBye(waitTimeout);
    }
    
    public synchronized boolean listenForIncomingCall(String name) throws Exception {
        return phones.get(name).listenForIncomingCall();
    }
    
    public synchronized boolean waitForInvite(String name, long waitTimeout) throws Exception {
        return phones.get(name).waitForInvite(waitTimeout);
    }
    
    public synchronized boolean waitForAck(String name, long waitTimeout) throws Exception {
        return phones.get(name).waitForAck(waitTimeout);
    }
    
    public synchronized boolean waitForReinviteAndRespond(String name, long waitTimeout, String sipAddress) throws Exception {
        return phones.get(name).waitForReinviteAndRespond(waitTimeout, sipAddress);
    }
    
    public synchronized boolean waitForCancel(String name, long waitTimeout) throws Exception {
        return phones.get(name).waitForCancel(waitTimeout);
    }    
    
    public synchronized boolean sendTrying(String name) throws Exception {
        return phones.get(name).sendTrying();
    }
    
    public synchronized boolean sendRinging(String name) throws Exception {
        return phones.get(name).sendRinging();
    }
    
    public synchronized boolean sendInviteOk(String name) throws Exception {
        return phones.get(name).sendInviteOk();
    }
    
    public synchronized boolean sendBusy(String name) throws Exception {
        return phones.get(name).sendBusy();
    }
    
    public synchronized void stopPhone(String name) throws Exception {
        if ( ! phones.containsKey(name)) {
            SipulatorPhone.log("Phone " + name + " NOT FOUND TO STOP!!");
            return;
        }
        SipulatorPhone phone = phones.get(name);
        phone.command("stop");
        phone.join(5000);
        phones.remove(name);
    }
}
