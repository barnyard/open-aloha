/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia.msml.model;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import noNamespace.BooleanDatatype;
import noNamespace.MomlNamelistDatatype;
import noNamespace.MsmlDocument;
import noNamespace.MsmlDocument.Msml;
import noNamespace.MsmlDocument.Msml.Dialogstart;
import noNamespace.MsmlDocument.Msml.Dialogstart.Dtmf;
import noNamespace.MsmlDocument.Msml.Dialogstart.Dtmf.Dtmfexit;
import noNamespace.MsmlDocument.Msml.Dialogstart.Dtmf.Pattern;

import org.apache.xmlbeans.XmlException;

import com.bt.aloha.media.DtmfCollectCommand;
import com.bt.aloha.util.MessageDigestHelper;


public class MsmlPromptAndCollectDigitsRequest extends MsmlRequest {
	public static final String PREFIX = "PPTCOL";
	private DtmfCollectCommand dtmfCollectCommand;

	public MsmlPromptAndCollectDigitsRequest(String aTargetAddress, DtmfCollectCommand aDtmfOptions) {
		this(aTargetAddress, PREFIX + MessageDigestHelper.generateDigest(), aDtmfOptions);
	}
	
	public MsmlPromptAndCollectDigitsRequest(String aTargetAddress, String aCommandId, DtmfCollectCommand aDtmfOptions) {
		super(aCommandId, aTargetAddress);
		
		if(aTargetAddress == null)
			throw new IllegalArgumentException("Target address for msml command must be specified");
		if(aDtmfOptions == null)
			throw new IllegalArgumentException("DTMF command options for msml command must be specified");
		
		this.dtmfCollectCommand = aDtmfOptions;
	}

	public DtmfCollectCommand getDtmfCollectCommand() {
		return dtmfCollectCommand;
	}

	@Override
	public String getXml() {
		MsmlDocument doc;
		try {
			doc = MsmlDocument.Factory.parse(new MsmlAnnouncementRequest(getTargetAddress(), getCommandId(), dtmfCollectCommand.getPromptFileUri(), dtmfCollectCommand.isAllowBarge(), dtmfCollectCommand.isClearBuffer(), MsmlApplicationEventType.DTMF_PLAY_COMMAND_COMPLETE).getXml());
		} catch (XmlException e) {
			throw new RuntimeException("Failed to generate prompt and collect command; parsing error for announcement command", e);
		}
		Msml msml = doc.getMsml();
		Dialogstart dialogStart = msml.getDialogstartArray(0);

		Dtmf dtmf = dialogStart.addNewDtmf();
		//dtmf.setCleardb(BooleanDatatype.Enum.forString(Boolean.valueOf(dtmfCollectCommand.isClearBuffer()).toString()));
		dtmf.setCleardb(BooleanDatatype.FALSE);
		dtmf.setFdt(dtmfCollectCommand.getFirstDigitTimeoutSeconds() + SECONDS);
		dtmf.setIdt(dtmfCollectCommand.getInterDigitTimeoutSeconds() + SECONDS);
		dtmf.setEdt(dtmfCollectCommand.getExtraDigitTimeoutSeconds() + SECONDS);

		Pattern pattern = dtmf.addNewPattern();
		pattern.setDigits(dtmfCollectCommand.getPattern().toString());
		pattern.setFormat("moml+digits");

		dtmf.addNewNoinput();
		dtmf.addNewNomatch();

		Dtmfexit dtmfexit = dtmf.addNewDtmfexit();
		noNamespace.MsmlDocument.Msml.Dialogstart.Dtmf.Dtmfexit.Send send = dtmfexit.addNewSend();

		List<MomlNamelistDatatype.Item.Enum> l = new ArrayList<MomlNamelistDatatype.Item.Enum>();
		l.add(MomlNamelistDatatype.Item.DTMF_DIGITS);
		l.add(MomlNamelistDatatype.Item.DTMF_END);

		send.setTarget(SOURCE);
		send.setEvent(MsmlApplicationEventType.DTMF_COLLECT_COMMAND_COMPLETE.value());
		send.setNamelist(l);

		Map<String,String> map = new Hashtable<String,String>();
        map.put(CVD_NS, CVD_PREFIX);

		return XML_PREFIX + doc.xmlText(super.createXmlOptions(map));
	}
}
