/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse.siploadbalancer;

import java.util.Vector;

import javax.sip.address.Address;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class RoundRobinHostManager {
	private static class InstanceHolder {
		public static RoundRobinHostManager instance = new RoundRobinHostManager();
	}
	
	private Log log = LogFactory.getLog(getClass());
	private int currentHostIndex = 0;
	private Object lock = new Object[0];
	private Vector<Address> hosts = new Vector<Address>();
	
	public static RoundRobinHostManager getInstance() {
		return InstanceHolder.instance;
	}
	
	public void setHosts(Vector<Address> hosts) {
		synchronized(lock) {
			this.hosts = hosts;
		}
	}
	
	public void removeHost(Address address) {
		synchronized (lock) {
			hosts.remove(address);
		}
	}
	
	public void addHost(Address address) {
		synchronized (lock) {
			if (!hosts.contains(address))
				hosts.add(address);
		}
	}
	
	public void setCurrentHostIndex(int hostIndex) {
		synchronized(lock) {
			this.currentHostIndex = hostIndex;
		}
	}
	
	public Address lookupHost() {
		synchronized (lock) {
			if(currentHostIndex > hosts.size()-1)
				currentHostIndex = 0;
			Address next = hosts.get(currentHostIndex);
			log.info(this.getClass().getSimpleName() + ": returning host # " + currentHostIndex + ": " + next.toString());
			currentHostIndex += 1;
			return next;
		}
	}
}
