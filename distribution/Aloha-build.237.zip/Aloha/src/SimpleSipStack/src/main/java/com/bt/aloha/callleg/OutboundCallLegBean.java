/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/**
 * (c) British Telecommunications plc, 2007, All Rights Reserved
 */
package com.bt.aloha.callleg;

import java.net.URI;

import javax.sdp.MediaDescription;

import com.bt.aloha.dialog.state.TerminationCause;

/**
 * Spring Bean to create and manage call legs.
 */
public interface OutboundCallLegBean extends CallLegBean {
    /**
     * Create a call leg with an answer timeout
     * @param from the originating sip URI
     * @param to the destination sip URI
     * @param callAnswerTimeout the number of seconds to wait for the destination to answer
     * @return the call leg ID
     */
	String createCallLeg(URI from, URI to, int callAnswerTimeout);

    /**
     * Create a call leg
     * @param from the originating sip URI
     * @param to the destination sip URI
     * @return the call leg ID
     */
	String createCallLeg(URI from, URI to);

    /**
     * Connect a call leg
     * @param callLegId the call leg ID
     */
    void connectCallLeg(String callLegId);

    /**
     * Connect a call leg specifying whether to auto-terminate the call leg
     * @param callLegId the call leg ID
     * @param autoTerminate whether to auto-terminate
     */
	void connectCallLeg(final String callLegId, final AutoTerminateAction autoTerminate);

    /**
     * Connect a call leg specifying whether to auto-terminate the call leg, the application data to store, and the media description to include
     * @param callLegId the call leg ID
     * @param autoTerminate whether to auto-terminate
     * @param mediaDescription the media description to add to the invite
     * @param applicationData the application data to store with this dialog info
     * @param shouldPlaceOnHold determines whether the connecting leg is automatically placed on hold upon connection by sending an ACK, or whether the responsibility for sending that ACK is delegated to the application
     */
	void connectCallLeg(final String callLegId, final AutoTerminateAction autoTerminate, final String applicationData, final MediaDescription mediaDescription, final boolean shouldPlaceOnHold);

    /**
     * Cancel a call leg before it is connected
     * @param callLegId the call leg ID
     */
	void cancelCallLeg(String callLegId);

    /**
     * Cancel a call leg before it is connected specifying a Termination Cause
     * @param callLegId the call leg ID
     * @param terminationCause the termination cause
     */
	void cancelCallLeg(String callLegId, TerminationCause terminationCause);

    /**
     * Add a listener to this OutboundCallLegBean
     * @param listener the OutboundCallLegListener to add
     */
	void addOutboundCallLegListener(OutboundCallLegListener listener);

    /**
     * Remove a listener from this OutboundCallLegBean
     * @param listener the OutboundCallLegListener to remove
     */
	void removeOutboundCallLegListener(OutboundCallLegListener listener);
}
