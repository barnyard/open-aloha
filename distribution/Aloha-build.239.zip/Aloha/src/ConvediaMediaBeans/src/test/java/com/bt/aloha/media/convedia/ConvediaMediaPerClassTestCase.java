/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;
import java.util.Vector;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bt.aloha.call.CallBean;
import com.bt.aloha.call.collections.CallCollection;
import com.bt.aloha.callleg.OutboundCallLegBean;
import com.bt.aloha.dialog.collections.DialogCollection;
import com.bt.aloha.media.MediaCallBean;
import com.bt.aloha.media.MediaCallLegBean;
import com.bt.aloha.media.testing.ConvediaMediaBeansPerClassTestCase;

public abstract class ConvediaMediaPerClassTestCase extends ConvediaMediaBeansPerClassTestCase {	
	private static final int TEN = 10;
	private static ClassPathXmlApplicationContext mockphoneApplicationContext;
	protected CallBean callBean;
	protected MediaCallBean mediaCallBean;
	protected MediaCallLegBean mediaCallLegBean;
	protected OutboundCallLegBean outboundCallLegBean;
	protected CallCollection callCollection;
	protected DialogCollection dialogCollection;
	protected List<Object> eventVector;
	protected Semaphore semaphore;

	private static void initializeMockphoneApplicationContext() {
    	mockphoneApplicationContext = new ClassPathXmlApplicationContext("testMockphoneApplicationContext.xml");
    	setSleepBeforeSendingMessages();
	}
	
	@Before
	public void convediaTestCaseBefore() {
    	callBean = (CallBean)getApplicationContext().getBean("callBean");
		mediaCallBean = (MediaCallBean)getApplicationContext().getBean("mediaCallBean");
		mediaCallLegBean = (MediaCallLegBean)getApplicationContext().getBean("mediaCallLegBean");
		outboundCallLegBean = (OutboundCallLegBean)getApplicationContext().getBean("outboundCallLegBean");
		callCollection = (CallCollection)getApplicationContext().getBean("callCollection");
		dialogCollection = (DialogCollection)getApplicationContext().getBean("dialogCollection");

		eventVector = new Vector<Object>();
		semaphore = new Semaphore(0);
	}

	private static void destroyMockphoneApplicationContext() {
		if (mockphoneApplicationContext != null)
			mockphoneApplicationContext.destroy();
	}

	@BeforeClass
	public static void beforeMethod() {
		initializeMockphoneApplicationContext();
	}

	@AfterClass
	public static void afterMethod() throws Exception {
		destroyMockphoneApplicationContext();
	}
	
	protected void waitForCallEvent(Class<?> eventClass) throws InterruptedException {
		assertTrue(semaphore.tryAcquire(TEN, TimeUnit.SECONDS));
		assertEquals(eventClass, eventVector.get(eventVector.size()-1).getClass());
	}
}
