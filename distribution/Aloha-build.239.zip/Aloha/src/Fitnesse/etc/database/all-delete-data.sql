-- connect as springringuser
delete from collections;
