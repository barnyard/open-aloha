/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/**
 * (c) British Telecommunications plc, 2007, All Rights Reserved
 */
package com.bt.aloha.call;

import java.util.Date;
import java.util.concurrent.ConcurrentMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.task.TaskExecutor;

import com.bt.aloha.call.collections.CallCollection;
import com.bt.aloha.call.state.CallInfo;
import com.bt.aloha.call.state.CallTerminationCause;
import com.bt.aloha.call.state.ReadOnlyCallInfo;

public class MaxCallDurationTermination {

	public static final int ONE_MINUTE_IN_MILLIS = 60000;
	private CallCollection callCollection;
	private CallBean callBean;
	private Log log = LogFactory.getLog(this.getClass());
	private MaxCallDurationScheduler maxCallDurationScheduler;
	private boolean runOnStartup;
	private TaskExecutor taskExecutor;

	public MaxCallDurationTermination(){}

	public void runTask() {
		log.debug("runTask()");
		this.taskExecutor.execute(new Runnable() {
			public void run() {
				initialize();
			}
		});
	}
	
	protected void initialize() {
		log.debug("initialize() runOnStartup = " + runOnStartup);
		if (runOnStartup) {
			ConcurrentMap<String, CallInfo> calls = callCollection.getAllConnectedCallsWithMaxDuration();
			log.debug(String.format("Initialising MaxCallDurationTermination object with %s call(s)", calls.size()));
			for (ReadOnlyCallInfo callInfo : calls.values())
				setTerminationTime(callInfo);
		}
	}

	private void setTerminationTime(ReadOnlyCallInfo callInfo) {
		long timeToTerminate = callInfo.getStartTime() + callInfo.getMaxDurationInMinutes() * ONE_MINUTE_IN_MILLIS;
		log.debug(String.format("CallId: %s, time to terminate: %s, current time: %s", callInfo.getId(), new Date(timeToTerminate).toString(), new Date(System.currentTimeMillis()).toString()));
		if (timeToTerminate <= System.currentTimeMillis()){
			log.debug(String.format("Request termination on callId %s", callInfo.getId()));
            try {
                callBean.terminateCall(callInfo.getId(), CallTerminationCause.MaximumCallDurationExceeded);
            } catch (Throwable t) {
                log.warn("Error terminating call", t);
            }
		} else {
			log.debug(String.format("Termination time is %s on callId %s", new Date(timeToTerminate).toString(), callInfo.getId()));
            try {
                maxCallDurationScheduler.terminateCallAfterMaxDuration((CallInfo)callInfo, callBean);
            } catch (Throwable t) {
                log.warn("Error scheduling call termination", t);
            }
		}
	}

	public void setCallBean(CallBean aCallBean) {
		this.callBean = aCallBean;
	}

	public void setCallCollection(CallCollection aCallCollection) {
		this.callCollection = aCallCollection;
	}

	public void setMaxCallDurationScheduler(MaxCallDurationScheduler aMaxCallDurationScheduler){
		this.maxCallDurationScheduler = aMaxCallDurationScheduler;
	}

	public void setRunOnStartup(String isRunOnStartup) {
		this.runOnStartup = Boolean.parseBoolean(isRunOnStartup);
	}

	public void setTaskExecutor(TaskExecutor aTaskExecutor) {
		this.taskExecutor = aTaskExecutor;
	}
}
