/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call;

import com.bt.aloha.call.state.CallTerminationCause;
import com.bt.aloha.callleg.AutoTerminateAction;
import com.bt.aloha.callleg.OutboundCallLegListener;

/**
 * Spring Bean to join call legs into calls and teminate them.
 */
public interface CallBean extends OutboundCallLegListener {
    /**
     * Join two call legs into a call.
     * @param firstDialogId the Call Leg ID of the first call leg
     * @param secondDialogId the Call Leg ID of the second call leg
     * @return the call ID
     */
	String joinCallLegs(String firstDialogId, String secondDialogId);

    /**
     * Join two call legs into a call setting auto-terminate.
     * @param firstDialogId the Call Leg ID of the first call leg
     * @param secondDialogId the Call Leg ID of the second call leg
     * @param autoTerminateCallLegs whether the call leg is automatically terminated when disconnected from a call
     * @return the call ID
     */
	String joinCallLegs(String firstDialogId, String secondDialogId, AutoTerminateAction autoTerminateCallLegs);

    /**
     * Join two call legs into a call setting auto-terminate and the maximum duration.
     * @param firstDialogId the Call Leg ID of the first call leg
     * @param secondDialogId the Call Leg ID of the second call leg
     * @param autoTerminationCallLegs whether the call leg is automatically terminated when disconnected from a call
     * @param durationInMinutes the maximum duration of the call in minutes
     * @return the call ID
     */
	String joinCallLegs(String firstDialogId, String secondDialogId, AutoTerminateAction autoTerminationCallLegs, long durationInMinutes);

	/**
     * Terminate a call
     * @param callId the ID of the call to terminate
	 */
    void terminateCall(String callId);

    /**
     * Terminate a call specifying a cause
     * @param callId the ID of the call to terminate
     * @param callTerminationCause the reason the call is terminated
     */
    void terminateCall(String callId, CallTerminationCause callTerminationCause);

	/**
     * Get information about a call
     * @param callId the ID of the call
     * @return information about the call
	 */
    CallInformation getCallInformation(String callId);

	/**
     * Add a call listener to the call bean
     * @param callListener the CallListener to add
	 */
    void addCallListener(CallListener callListener);

    /**
     * remove a call listener from the call bean
     * @param callListener the listener to remove
     */
	void removeCallListener(CallListener callListener);
}
