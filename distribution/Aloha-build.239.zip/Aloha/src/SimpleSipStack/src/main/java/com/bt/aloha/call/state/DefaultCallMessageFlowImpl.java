/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call.state;

import javax.sdp.MediaDescription;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.dialog.state.ImmutableDialogInfo;
import com.bt.aloha.stack.SessionDescriptionHelper;

public class DefaultCallMessageFlowImpl implements CallMessageFlow {
	private static final Log LOG = LogFactory.getLog(DefaultCallMessageFlowImpl.class);

	public DefaultCallMessageFlowImpl() {
	}

	public MediaNegotiationCommand initializeCall(ImmutableDialogInfo firstDialogInfo, ImmutableDialogInfo secondDialogInfo, ReadOnlyCallInfo callInfo, MediaDescription offerMediaDescription) {
		LOG.debug(String.format("Initializing call %s using sip flow %s", callInfo.getId(), this.getClass().getSimpleName()));
		if (callInfo.areBothCallLegsConnected()) {
			return new InitiateMediaNegotiationCommand(firstDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), callInfo.getCallLegConnectionState(firstDialogInfo.getId()));
		} else {
			CallLegConnectionState firstConnectionState = callInfo.getCallLegConnectionState(firstDialogInfo.getId());
			CallLegConnectionState secondConnectionState = callInfo.getCallLegConnectionState(secondDialogInfo.getId());
			if (firstConnectionState.equals(CallLegConnectionState.Pending))
				return new ConnectAndHoldCommand(firstDialogInfo, firstConnectionState, callInfo.getAutoTerminate(), null);
			else if (secondConnectionState.equals(CallLegConnectionState.Pending))
				return new ConnectAndHoldCommand(secondDialogInfo, secondConnectionState, callInfo.getAutoTerminate(), null);
			else
				return null;
    	}
	}

	public MediaNegotiationCommand processCallLegConnected(ImmutableDialogInfo eventDialogInfo, ImmutableDialogInfo otherDialogInfo, ReadOnlyCallInfo callInfo, boolean refreshOriginatedByCurrentCall, MediaDescription mediaDescription) {
		LOG.debug(String.format("Processing call leg connected event for call leg %s in call %s using sip flow %s, refresh originated by call is %s", eventDialogInfo.getId(), callInfo.getId(), this.getClass().getSimpleName(), refreshOriginatedByCurrentCall));
		
		MediaNegotiationCommand command = null;
		if (refreshOriginatedByCurrentCall)
			command = processCallLegConnectedRefreshOriginatedByCurrentCall(eventDialogInfo, otherDialogInfo, callInfo, refreshOriginatedByCurrentCall, mediaDescription);
		else if (callInfo.areBothCallLegsConnected() && callInfo.getMediaNegotiationState().equals(MediaNegotiationState.Pending)) {
			ImmutableDialogInfo firstDialogInfo = eventDialogInfo.getId().equals(callInfo.getFirstDialogId()) ? eventDialogInfo : otherDialogInfo;
			command = new InitiateMediaNegotiationCommand(firstDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), callInfo.getCallLegConnectionState(firstDialogInfo.getId()));
		}
		return command;
	}
	
	protected MediaNegotiationCommand processCallLegConnectedRefreshOriginatedByCurrentCall(ImmutableDialogInfo eventDialogInfo, ImmutableDialogInfo otherDialogInfo, ReadOnlyCallInfo callInfo, boolean refreshOriginatedByCall, MediaDescription mediaDescription) {
		CallLegConnectionState otherConnectionState = callInfo.getCallLegConnectionState(otherDialogInfo.getId());    	
    	
		if (callInfo.getMediaNegotiationState().equals(MediaNegotiationState.Initiated)) {
			return new ProxyMediaOfferCommand(otherDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), mediaDescription, otherConnectionState);
		} else if (callInfo.getMediaNegotiationState().equals(MediaNegotiationState.ProxiedOffer)) {
			return new AcceptMediaOfferCommand(otherDialogInfo, mediaDescription, otherConnectionState, callInfo.getMediaNegotiationState(), callInfo.getMediaNegotiationMethod());
		}
		return null;
	}

	public MediaNegotiationCommand processCallLegRefreshCompleted(ImmutableDialogInfo firstDialogInfo, ImmutableDialogInfo secondDialogInfo, ReadOnlyCallInfo callInfo, boolean isEventForFirstCallLeg, MediaDescription answerMediaDescription) {
		LOG.debug(String.format("Processing call leg refresh completed event for call %s using sip flow %s", callInfo.getId(), this.getClass().getSimpleName()));
		ImmutableDialogInfo otherDialogInfo = isEventForFirstCallLeg ? secondDialogInfo : firstDialogInfo;
		
		LOG.debug("Proxying reinvite response back to dialog which originated the negotiation");
		return new AcceptMediaOfferCommand(otherDialogInfo, answerMediaDescription, callInfo.getCallLegConnectionState(otherDialogInfo.getId()), callInfo.getMediaNegotiationState(), callInfo.getMediaNegotiationMethod());
	}

	public MediaNegotiationCommand processReceivedCallLegRefresh(ImmutableDialogInfo eventDialogInfo, ImmutableDialogInfo otherDialogInfo, ReadOnlyCallInfo callInfo, boolean isOfferInOkResponse, MediaDescription offerMediaDescription) {
		LOG.debug(String.format("Processing received call leg refresh event for call %s using sip flow %s", callInfo.getId(), this.getClass().getSimpleName()));
		return new ProxyMediaOfferCommand(otherDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), offerMediaDescription, callInfo.getCallLegConnectionState(otherDialogInfo.getId()));
	}

	public MediaNegotiationCommand processReceivedCallLegRefreshForTerminatedCall(ImmutableDialogInfo eventDialogInfo, MediaDescription mediaDescription, ReadOnlyCallInfo terminatedCallInfo) {
		LOG.debug(String.format("Processing received call leg refresh event (call leg %s) for terminated call %s using sip flow %s", eventDialogInfo.getId(), terminatedCallInfo.getId(), this.getClass().getSimpleName()));
		MediaDescription holdMediaDescription = SessionDescriptionHelper.generateHoldMediaDescription(mediaDescription);

		return new AcceptMediaOfferCommand(eventDialogInfo, holdMediaDescription, terminatedCallInfo.getCallLegConnectionState(eventDialogInfo.getId()), terminatedCallInfo.getMediaNegotiationState(), terminatedCallInfo.getMediaNegotiationMethod());
	}

	public MediaNegotiationCommand processCallLegConnectionFailed(ImmutableDialogInfo eventDialogInfo, ImmutableDialogInfo otherDialogInfo, CallInfo callInfo) {
		return null;
	}
}

