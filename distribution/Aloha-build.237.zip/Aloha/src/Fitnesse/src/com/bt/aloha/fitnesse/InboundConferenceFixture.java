/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.callleg.InboundCallLegListener;
import com.bt.aloha.callleg.event.IncomingCallLegEvent;
import com.bt.aloha.dialog.event.IncomingAction;
import com.bt.aloha.eventing.EventFilter;
import com.bt.aloha.media.conference.event.ConferenceActiveEvent;
import com.bt.aloha.media.conference.event.ConferenceEndedEvent;
import com.bt.aloha.media.conference.event.ParticipantConnectedEvent;
import com.bt.aloha.media.conference.event.ParticipantDisconnectedEvent;
import com.bt.aloha.media.conference.event.ParticipantFailedEvent;
import com.bt.aloha.media.conference.event.ParticipantTerminatedEvent;
import com.bt.aloha.media.conference.state.ConferenceTerminationCause;
import com.bt.aloha.media.convedia.conference.ConferenceBean;
import com.bt.aloha.media.convedia.conference.ConferenceBeanImpl;
import com.bt.aloha.media.convedia.conference.ConferenceListener;
import com.bt.aloha.testing.CallLegListenerStubBase;

public class InboundConferenceFixture extends InboundDialogFixture implements ConferenceListener {
    private ConferenceBean conferenceBean;
    private String conferenceId;
    private int activeParticipant;
	private List<String> participantConnectedEvents = new Vector<String>();
	private Semaphore participantConnectedSemaphore = new Semaphore(0);
	private String conferenceActiveEventId;
	private Semaphore conferenceActiveSemaphore = new Semaphore(0);
	private ConferenceEndedEvent conferenceEndedEvent;
	private Semaphore conferenceEndedSemaphore = new Semaphore(0);

    public InboundConferenceFixture() {
        super();
        conferenceBean = (ConferenceBean)FixtureApplicationContexts.getInstance()
        	.startInboundApplicationContext().getBean("conferenceBean");
        List<ConferenceListener> list = new ArrayList<ConferenceListener>();
        list.add(this);
        ((ConferenceBeanImpl)conferenceBean).setConferenceListeners(list);

        inboundApplicationContextBeans.getInboundCallLegBean().addInboundCallLegListener(new InboundConferenceCallLegListener());
    }

	public void activeParticipant(int participant) {
		this.activeParticipant = participant;
	}

    public class InboundConferenceCallLegListener extends CallLegListenerStubBase implements InboundCallLegListener, EventFilter {
        private Log log = LogFactory.getLog(this.getClass());

        public void onIncomingCallLeg(IncomingCallLegEvent e) {
            e.setIncomingCallAction(IncomingAction.None);
            String incomingDialogId = e.getId();
            
            log.debug("Got onIncomingDialog in the InboundConferenceCallLegListener, adding to conference");
            conferenceBean.inviteParticipant(conferenceId, incomingDialogId);
        }

        public boolean shouldDeliverEvent(Object event) {
            return event instanceof IncomingCallLegEvent
               && ((IncomingCallLegEvent) event).getToUri().contains("conference");
        }
    }
    
    public String createConference() {
    	conferenceId = conferenceBean.createConference();
    	return conferenceId;
    }

    public String createDialog() {
    	try {
    		switch (activeParticipant) {
		        case 1:
		            firstDialogId = conferenceBean.createParticipantCallLeg(conferenceId, URI.create(firstPhoneUri));
		            break;
		        case 2:
		            secondDialogId = conferenceBean.createParticipantCallLeg(conferenceId, URI.create(secondPhoneUri));
		            break;
		        case 3:
		            thirdDialogId = conferenceBean.createParticipantCallLeg(conferenceId, URI.create(thirdPhoneUri));
		            break;
	        }
    		return "OK";
		} catch (Exception e) {
			return "Exception:" + e.getClass().getSimpleName();
		}
    }

    private String getDialogId() {
    	switch (activeParticipant) {
	    	case 1:
	    		return firstDialogId;
	    	case 2:
	    		return secondDialogId;
	    	case 3:
	    		return thirdDialogId;
	    	default:
	    		return null;
    	}
    }
    
    public String inviteParticipant() {
    	try {
    		conferenceBean.inviteParticipant(conferenceId, getDialogId());
    		return "OK";
    	} catch (Exception e) {
    		return "Exception:" + e.getClass().getSimpleName();
    	}
    }

    public int numberOfActiveParticipants () {
    	return conferenceBean.getConferenceInformation(conferenceId).getNumberOfActiveParticipants();
    }

    public String endConference() {
		conferenceBean.endConference(conferenceId);
		return "OK";
    }

    public String waitForParticipantConnectedEvent() throws Exception {
	    String targetDialogId = getDialogId();
	    if (participantConnectedSemaphore.tryAcquire(waitTimeoutSeconds, TimeUnit.SECONDS)) {
	        if (participantConnectedEvents.contains(targetDialogId))
	            return "OK";
            return participantConnectedEvents.toString();
	    }
	    return "No event";
    }

    public String waitForConferenceActiveEvent() throws Exception {
	    if (conferenceActiveSemaphore.tryAcquire(waitTimeoutSeconds, TimeUnit.SECONDS)) {
	        if (conferenceActiveEventId.equals(conferenceId))
	            return "OK";
            return conferenceActiveEventId;
	    }
	    return "No event";
    }

    public String waitForConferenceEndedEventWithEndedByApplication() throws Exception {
    	return waitForConferenceEndedEvent(ConferenceTerminationCause.EndedByApplication);
    }

    private String waitForConferenceEndedEvent(ConferenceTerminationCause conferenceTerminationCause) throws Exception {
	    if (conferenceEndedSemaphore.tryAcquire(waitTimeoutSeconds, TimeUnit.SECONDS)) {
	        if (conferenceEndedEvent.getConferenceId().equals(conferenceId) && conferenceEndedEvent.getConferenceTerminationCause().equals(conferenceTerminationCause))
	            return "OK";
            return conferenceEndedEvent.getConferenceId() + conferenceEndedEvent.getConferenceTerminationCause();
	    }
	    return "No event";
    }

	public void onConferenceActive(ConferenceActiveEvent conferenceActiveEvent) {
		conferenceActiveEventId = conferenceActiveEvent.getConferenceId();
		conferenceActiveSemaphore.release();
	}

	public void onConferenceEnded(ConferenceEndedEvent aConferenceEndedEvent) {
		conferenceEndedEvent = aConferenceEndedEvent;
		conferenceEndedSemaphore.release();
	}

	public void onParticipantConnected(ParticipantConnectedEvent participantConnectedEvent) {
		participantConnectedEvents.add(participantConnectedEvent.getDialogId());
		participantConnectedSemaphore.release();
	}

	public void onParticipantDisconnected(ParticipantDisconnectedEvent participantDisconnectedEvent) {
	}

	public void onParticipantFailed(ParticipantFailedEvent participantFailedEvent) {
	}

	public void onParticipantTerminated(ParticipantTerminatedEvent participantTerminatedEvent) {
	}
}
