/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import fit.Fixture;

public class SetupFixture extends Fixture {

    private static Log log = LogFactory.getLog(SetupFixture.class);

    private Properties loadDatabaseProperties() {
        try {
            InputStream is = Thread.currentThread().getContextClassLoader()
                    .getResourceAsStream("database.properties");
            Properties p = new Properties();
            p.load(is);
            return p;
        } catch (IOException e) {
            throw new IllegalStateException(
                    "Unable to load properties from 'database.properties'. Maybe it's not in the classpath??");
        }
    }

    private Connection getConnection(Properties p) {
        Connection connection = null;
        String driverName = null;
        try {
            driverName = p.getProperty("sssDatasource.driverClassName");
            String url = p.getProperty("sssDatasource.url");
            String username = p.getProperty("sssDatasource.username");
            String password = p.getProperty("sssDatasource.password");
            // Load the JDBC driver
            Class.forName(driverName);
            // Create a connection to the database
            connection = DriverManager.getConnection(url, username, password);
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("Unable to load driver class "
                    + driverName + ". Check the classpath");
        } catch (SQLException e) {
            throw new IllegalStateException("Unable to connect to database", e);
        }
        return connection;
    }

    public int clearDatabaseData(){
        Connection c = getConnection(loadDatabaseProperties());
        Statement statement = null;
        int deletedRows = 0;
        try{
            statement = c.createStatement();
            deletedRows = statement.executeUpdate("delete from StateInfo");
            deletedRows += statement.executeUpdate("delete from callinfo");
            deletedRows += statement.executeUpdate("delete from conferenceinfo");
            return deletedRows;
        }
        catch(SQLException e){
            throw new IllegalStateException("Unable to delete data", e);
        }
        finally{
            if (statement != null){
                try {
                    statement.close();
                } catch (SQLException e) {
                    log.warn(e);
                }
            }
            if (c != null){
                try {
                    c.close();
                } catch (SQLException e) {
                    log.warn(e);
                }
            }
        }
    }

    public static void main(String[] args) {
        new SetupFixture().clearDatabaseData();
    }
}
