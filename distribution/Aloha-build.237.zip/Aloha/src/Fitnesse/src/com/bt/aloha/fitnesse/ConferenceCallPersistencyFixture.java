/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse;

import java.util.Vector;

import com.bt.aloha.call.CallBean;
import com.bt.aloha.call.CallBeanImpl;
import com.bt.aloha.media.convedia.conference.ConferenceBeanImpl;

public class ConferenceCallPersistencyFixture extends CallPersistencyFixtureBase {
	private String firstPhoneUri;
	private String secondPhoneUri;
    private String conferenceId;
    private Vector<String> participants = new Vector<String>();
    private ConferenceFixture conferenceFixture;
    private long maxDuration = 0;

	static{
		// make sure to load this app ctx
		FixtureApplicationContexts.getInstance().startMockphonesApplicationContext();
	}

	public ConferenceCallPersistencyFixture() {
	}

    public void destroyPersistencyApplicationContext(){
        FixtureApplicationContexts.getInstance().destroyPersistencyApplicationContext();
    }

	public String startApplicationContext(){
		applicationContext = FixtureApplicationContexts.getInstance().startPersistencyApplicationContext();
		return "OK";
	}

	public String destroyAndStartApplicationContext(){
		applicationContext = FixtureApplicationContexts.getInstance().startPersistencyApplicationContext(true, getJvmDownTime());
        setupConferenceFixture();
        conferenceFixture.setConfId(conferenceId);
        conferenceFixture.setOurDialogIds(participants);
        return "OK";
	}

	private void setupConferenceFixture() {
		int activeParticipant = 0;
		if (conferenceFixture != null)
			activeParticipant = conferenceFixture.getActiveParticipant();
		conferenceFixture = new ConferenceFixture(applicationContext);
		conferenceFixture.activeParticipant(activeParticipant);
        conferenceFixture.ipAddressPattern(getIpAddressPattern());
        conferenceFixture.firstPhoneUri(firstPhoneUri);
        conferenceFixture.secondPhoneUri(secondPhoneUri);
        conferenceFixture.waitTimeoutSeconds(getWaitTimeoutSeconds());
        conferenceFixture.setMaxDurationInMinutes(maxDuration);
        
        ConferenceBeanImpl conferenceBean = (ConferenceBeanImpl)applicationContext.getBean("conferenceBean");
        CallBean callBean = (CallBean)applicationContext.getBean("callBean");
        
        if (!((CallBeanImpl)callBean).getCallListeners().contains(conferenceBean))
        	callBean.addCallListener(conferenceBean);
	}
	
	public String createConference(){
		setupConferenceFixture();
		conferenceId = conferenceFixture.createConference();
		return conferenceId;
	}
	
	public void setActiveParticipant(int part){
		conferenceFixture.activeParticipant(part);
	}
	
	public String inviteParticipant(){
		conferenceFixture.createDialog();
		conferenceFixture.inviteParticipant();
		participants = (Vector<String>)conferenceFixture.getOurDialogIds();
		return participants.lastElement();
	}
	
	public String waitForParticipantConnectedEvent() throws Exception {
		return conferenceFixture.waitForParticipantConnectedEvent();
	}
	
	public String waitForConferenceActiveEvent() throws Exception {
		return conferenceFixture.waitForConferenceActiveEvent();
	}
	
	public String endConference(){
		return conferenceFixture.endConference();
	}
	
	public String waitForParticipantTerminatedEvent() throws Exception{
		return conferenceFixture.waitForParticipantTerminatedEvent();
	}
	
	public String waitForParticipantDisconnectedEvent() throws Exception {
		return conferenceFixture.waitForParticipantDisconnectedEvent();
	}
	
	public String waitForConferenceEndedEventWithLastParticipantDisconnected() throws Exception {
		return conferenceFixture.waitForConferenceEndedEventWithLastParticipantDisconnected();
	}
	
	public String waitForConferenceEndedEventWithEndedByApplication() throws Exception{
		return conferenceFixture.waitForConferenceEndedEventWithEndedByApplication();
	}
	
	public String waitForConferenceEndedEventWithMaxDurationExceeded() throws Exception {
		return conferenceFixture.waitForConferenceEndedEventWithMaxDurationExceeded();
	}

	public void setFirstPhoneUri(String firstPhoneUri) {
		this.firstPhoneUri = firstPhoneUri;
	}
	
	public String createConferenceWithOneMinuteDuration(){
		maxDuration = 1;
		return createConference();
	}

	public int numberOfActiveParticipants(){
		return conferenceFixture.numberOfActiveParticipants();
	}
	
	@Override
	public void setWaitTimeoutSeconds(int waitTimeoutSeconds) {
		super.setWaitTimeoutSeconds(waitTimeoutSeconds);
		if (conferenceFixture != null)
			conferenceFixture.waitTimeoutSeconds(waitTimeoutSeconds);
	}

	public String getSecondPhoneUri() {
		return secondPhoneUri;
	}

	public void setSecondPhoneUri(String secondPhoneUri) {
		this.secondPhoneUri = secondPhoneUri;
	}
}
