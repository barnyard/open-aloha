/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call.state;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ScheduledFuture;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.callleg.AutoTerminateAction;
import com.bt.aloha.state.StateInfoBase;

public class CallInfo extends StateInfoBase<CallInfo> implements ReadOnlyCallInfo {
    static final String CALL_LEG_S_NOT_IN_CALL_S = "Call leg %s not in call %s";
    private static final String FUTURE = "future";
    private static final long serialVersionUID = 1L;
    private static Log log = LogFactory.getLog(CallInfo.class);
    private CallState callState = CallState.Connecting;
    private String firstDialogId;
    private String secondDialogId;
    private CallLegConnectionState firstCallLegConnectionState = CallLegConnectionState.Pending;
    private CallLegConnectionState secondCallLegConnectionState = CallLegConnectionState.Pending;
    private MediaNegotiationState mediaNegotiationState = MediaNegotiationState.Pending;
    private MediaNegotiationMethod mediaNegotiationMethod;
    private long maxDurationInMinutes;
    private transient ScheduledFuture<?> future;
    private AutoTerminateAction autoTerminate;
    private CallTerminationCause callTerminationCause;
    private CallLegCausingTermination callLegCausingTermination;
    private PendingCallReinvite pendingCallReinvite;

    public CallInfo(String creatingBeanName, String aCallId, String theFirstDialogId, String theSecondDialogId, AutoTerminateAction aAutoTerminate, long theMaxDurationInMinutes) {
        super(creatingBeanName);
        this.firstDialogId = theFirstDialogId;
        this.secondDialogId = theSecondDialogId;
        setId(aCallId);
        this.maxDurationInMinutes = theMaxDurationInMinutes;
        this.callTerminationCause = null;
        this.callLegCausingTermination = null;
        this.mediaNegotiationMethod = null;
        this.autoTerminate = aAutoTerminate;
        this.pendingCallReinvite = null;
    }

    @Override
    public CallInfo cloneObject() {
        return (CallInfo)super.cloneObject();
    }

    public String getFirstDialogId() {
        return firstDialogId;
    }

    public String getSecondDialogId() {
        return secondDialogId;
    }

    public CallState getCallState() {
        return callState;
    }

    public long getMaxDurationInMinutes() {
        return maxDurationInMinutes;
    }

    public void setMaxDurationInMinutes(long aMaxDurationInMinutes) {
        maxDurationInMinutes = aMaxDurationInMinutes;
    }

    /**
     *
     * @param newCallState
     * @return Previous call state if the update resulted in the call state
     *         being advanced, null if it did not
     */
    public CallState setCallState(CallState newCallState) {
        CallState currentCallState = callState;
        if (newCallState.ordinal() > currentCallState.ordinal()) {
            this.callState = newCallState;
            updateLastUsedTime();

            if (newCallState.equals(CallState.Connected))
                setStartTime(Calendar.getInstance().getTimeInMillis());
            if (newCallState.equals(CallState.Terminated))
                setEndTime(Calendar.getInstance().getTimeInMillis());

            return currentCallState;
        }

        log.debug(String.format(
                "Attempt to set call state to same or previous or current (%s to %s) for call %s",
                currentCallState, newCallState, getId()));
        return null;
    }

    public ScheduledFuture<?> getFuture() {
        return future;
    }

    public void setFuture(ScheduledFuture<?> scheduledFuture) {
        this.future = scheduledFuture;
    }

    public CallTerminationCause getCallTerminationCause() {
        return callTerminationCause;
    }

    public CallLegCausingTermination getCallLegCausingTermination() {
        return callLegCausingTermination;
    }

    public boolean setCallTerminationCause(CallTerminationCause aCallTerminationCause, CallLegCausingTermination aCallLegCausingTermination) {
        if (this.callTerminationCause == null) {
            this.callTerminationCause = aCallTerminationCause;
            this.callLegCausingTermination = aCallLegCausingTermination;
            return true;
        }
        log.debug(String.format(
                "Attempt to set call termination cause twice (current cause:%s, new cause:%s, leg causing:%s) for call %s",
                this.callTerminationCause, aCallTerminationCause, aCallLegCausingTermination, getId()));

        return false;
    }

    @Override
    public boolean isDead() {
        return this.callState.equals(CallState.Terminated);
    }

    @Override
    public Map<String, Object> getTransients() {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put(FUTURE, this.getFuture());
        return result;
    }

    @Override
    public void setTransients(Map<String, Object> m) {
        if (m.containsKey(FUTURE)) this.setFuture((ScheduledFuture<?>)m.get(FUTURE));

    }

    public AutoTerminateAction getAutoTerminate() {
        return autoTerminate;
    }

    public Class<? extends CallMessageFlow> getCallMessageFlow() {
        return DefaultCallMessageFlowImpl.class;
    }

    public MediaNegotiationState getMediaNegotiationState() {
        return mediaNegotiationState;
    }

    public void setMediaNegotiationState(MediaNegotiationState aMediaNegotiationState) {
        this.mediaNegotiationState = aMediaNegotiationState;
    }

    public CallLegConnectionState getCallLegConnectionState(String callLegId) {
        if (firstDialogId.equals(callLegId))
            return firstCallLegConnectionState;
        else if (secondDialogId.equals(callLegId))
            return secondCallLegConnectionState;
        else
            throw new IllegalArgumentException(String.format(CALL_LEG_S_NOT_IN_CALL_S, callLegId, getId()));
    }

    public void setCallLegConnectionState(String callLegId, CallLegConnectionState aCallLegConnectionState) {
        if (aCallLegConnectionState == null)
            throw new IllegalArgumentException(String.format("Null call leg conn state for leg %s in call %s", callLegId, getId()));

        if (firstDialogId.equals(callLegId)) {
            log.debug(String.format("Set first leg (%s) connection state to %s for call %s", callLegId, aCallLegConnectionState, getId()));
            this.firstCallLegConnectionState = aCallLegConnectionState;
        } else if (secondDialogId.equals(callLegId)) {
            log.debug(String.format("Set second leg (%s) connection state to %s for call %s", callLegId, aCallLegConnectionState, getId()));
            this.secondCallLegConnectionState = aCallLegConnectionState;
        } else
            throw new IllegalArgumentException(String.format(CALL_LEG_S_NOT_IN_CALL_S, callLegId, getId()));
    }

    public boolean areBothCallLegsConnected() {
        return firstCallLegConnectionState.equals(CallLegConnectionState.Completed)
            && secondCallLegConnectionState.equals(CallLegConnectionState.Completed);
    }

    public MediaNegotiationMethod getMediaNegotiationMethod() {
        return mediaNegotiationMethod;
    }

    // TODO: check that having made it public - from protected - to allow creation of a CallInfo loaded from db, is OK
    public void setMediaNegotiationMethod(MediaNegotiationMethod aMediaNegotiationMethod) {
        this.mediaNegotiationMethod = aMediaNegotiationMethod;
    }

    public PendingCallReinvite getPendingCallReinvite() {
        return pendingCallReinvite;
    }

    public void setPendingCallReinvite(PendingCallReinvite aPendingCallReinvite) {
        this.pendingCallReinvite = aPendingCallReinvite;
    }

    public CallLegConnectionState getFirstCallLegConnectionState() {
        return firstCallLegConnectionState;
    }

    public CallLegConnectionState getSecondCallLegConnectionState() {
        return secondCallLegConnectionState;
    }
}
