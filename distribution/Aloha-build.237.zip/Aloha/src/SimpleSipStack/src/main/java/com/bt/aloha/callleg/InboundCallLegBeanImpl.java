/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/**
 * (c) British Telecommunications plc, 2007, All Rights Reserved
 */
package com.bt.aloha.callleg;



import java.util.ArrayList;
import java.util.List;

import javax.sdp.MediaDescription;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.dialog.DialogBeanHelper;
import com.bt.aloha.dialog.DialogSipListener;
import com.bt.aloha.dialog.collections.DialogCollection;
import com.bt.aloha.dialog.inbound.InboundDialogSipBeanImpl;
import com.bt.aloha.dialog.state.ReadOnlyDialogInfo;
import com.bt.aloha.dialog.state.TerminationCause;
import com.bt.aloha.dialog.state.TerminationMethod;
import com.bt.aloha.util.ConcurrentUpdateManager;
import com.bt.aloha.util.HousekeeperAware;

public class InboundCallLegBeanImpl extends InboundDialogSipBeanImpl implements InboundCallLegBean, HousekeeperAware  {
	private static final Log LOG = LogFactory.getLog(InboundCallLegBeanImpl.class);
	private CallLegHelper callLegHelper = new CallLegHelper() {
		@Override
		protected void endNonConfirmedDialog(ReadOnlyDialogInfo dialogInfo, TerminationMethod previousTerminationMethod) {
			InboundCallLegBeanImpl.this.endNonConfirmedDialog(dialogInfo, previousTerminationMethod);
		}

		@Override
		protected ConcurrentUpdateManager getConcurrentUpdateManager() {
			return InboundCallLegBeanImpl.this.getConcurrentUpdateManager();
		}

		@Override
		protected DialogCollection getDialogCollection() {
			return InboundCallLegBeanImpl.this.getDialogCollection();
		}
		
		@Override
		protected void acceptReceivedMediaOffer(String dialogId, MediaDescription mediaDescription, boolean offerInOkResponse, boolean initialInviteTransactionCompleted) {
			LOG.debug(String.format("Accepting media offer for call leg %s, offer in ok response is %s, initial tx completed is %s", dialogId, offerInOkResponse, initialInviteTransactionCompleted));
			if (initialInviteTransactionCompleted) { 
				if (offerInOkResponse)
					InboundCallLegBeanImpl.this.sendReinviteAck(dialogId, mediaDescription);
				else
					InboundCallLegBeanImpl.this.sendReinviteOkResponse(dialogId, mediaDescription);
			} else {
				InboundCallLegBeanImpl.this.sendInitialOkResponse(dialogId, mediaDescription, null);
			}
		}
	};

    public InboundCallLegBeanImpl() {
        super();
    }

   	@Override
	public DialogBeanHelper getDialogBeanHelper() {
   		return callLegHelper;
	}

	public void addInboundCallLegListener(InboundCallLegListener listener) {
		super.addInboundDialogListener(new InboundCallLegListenerAdapter(listener));
	}

	public void removeInboundCallLegListener(InboundCallLegListener listener) {
		super.removeInboundDialogListener(new InboundCallLegListenerAdapter(listener));
	}

	public void setInboundCallLegListeners(List<InboundCallLegListener> listeners) {
		List<DialogSipListener> dialogSipListeners = new ArrayList<DialogSipListener>();
		for (InboundCallLegListener listener : listeners) {
			dialogSipListeners.add(new InboundCallLegListenerAdapter(listener));
		}
		this.setDialogSipListeners(dialogSipListeners);
	}

	public void reinviteCallLeg(String dialogId, MediaDescription offerMediaDescription, AutoTerminateAction autoTerminate, String applicationData) {
		super.reinviteDialog(dialogId, offerMediaDescription, autoTerminate.getBoolean(), applicationData);
	}

	public boolean acceptIncomingCallLeg(String dialogId, MediaDescription mediaDescription, String applicationData) {
		return sendInitialOkResponse(dialogId, mediaDescription, applicationData);
	}

	public boolean rejectIncomingCallLeg(String dialogId, int statusCode) {
		return sendInitialErrorResponse(dialogId, statusCode);
	}

	public boolean sendRingingResponse(final String dialogId) {
		return super.sendRingingResponse(dialogId);
	}

	public void terminateCallLeg(String dialogId) {
		this.callLegHelper.terminateCallLeg(dialogId, TerminationCause.TerminatedByServer);
	}

	public void terminateCallLeg(String dialogId, TerminationCause aDialogTerminationCause) {
		this.callLegHelper.terminateCallLeg(dialogId, aDialogTerminationCause);
	}

	public CallLegInformation getCallLegInformation(String dialogId) {
		return this.callLegHelper.getCallLegInformation(dialogId);
	}

	public void killHousekeeperCandidate(String infoId) {
		terminateCallLeg(infoId, TerminationCause.Housekept);
	}

	public void acceptReceivedMediaOffer(String dialogId, MediaDescription mediaDescription, boolean offferInOkResponse, boolean initialInviteTransactionCompleted) {
		this.callLegHelper.acceptReceivedMediaOffer(dialogId, mediaDescription, offferInOkResponse, initialInviteTransactionCompleted);
	}
}
