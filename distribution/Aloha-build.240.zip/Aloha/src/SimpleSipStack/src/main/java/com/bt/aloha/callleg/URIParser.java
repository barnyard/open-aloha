/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/**
 * (c) British Telecommunications plc, 2008, All Rights Reserved
 */
package com.bt.aloha.callleg;

import java.net.URI;

public class URIParser {
	
	private static final String EQUALS = "=";
	private static final String SEMICOLON = ";";
	private String usernameParameterName = "username";
	private String passwordParameterName = "password";
	private Boolean removeUserAndPasswordParameters = true;
	
	public URIParser(){
		
	}
	
	public URIParameters parseURI(URI uri){
		String username = extractParameter(uri, usernameParameterName);
		String password = extractParameter(uri, passwordParameterName);
		URI strippedURI = uri;
		if (removeUserAndPasswordParameters)
			strippedURI = this.removeUserAndPasswordParams(uri);
		return new URIParameters(username, password, strippedURI);
	}
	
	private String extractParameter(URI uri, String parameterName){
		String uriString = uri.toString();
		String result = null;
		String parameterToken = SEMICOLON + parameterName + EQUALS;
		int parameterStart = uriString.indexOf(parameterToken);
		if (parameterStart > -1){
			int parameterEnd = uriString.indexOf(SEMICOLON, parameterStart+parameterToken.length());
			if (parameterEnd < 0)
				parameterEnd=uriString.length();
			result = uriString.substring(parameterStart + parameterToken.length(), parameterEnd);
			if (result.length() < 1)
				result=null;
		}
		return result;
	}
	


	public void setUsernameParameterName(String aUsernameParameterName) {
		this.usernameParameterName = aUsernameParameterName;
	}

	public void setPasswordParameterName(String aPasswordParameterName) {
		this.passwordParameterName = aPasswordParameterName;
	}

	public void setRemoveUserAndPasswordParameters(
			Boolean aRemoveUserAndPasswordParameters) {
		removeUserAndPasswordParameters = aRemoveUserAndPasswordParameters;
	}
	
	private URI removeUserAndPasswordParams(URI uri){
		String uriString = uri.toString();
		String[] parts = uriString.split(SEMICOLON);
		StringBuffer buf = new StringBuffer(parts[0]);
		for(int i=1;i<parts.length;i++)
		{
			if (!(parts[i].contains(usernameParameterName +EQUALS) || parts[i].contains(passwordParameterName+ EQUALS)))
				buf.append(SEMICOLON + parts[i]);
		}
				 
		return URI.create(buf.toString());
	}

}
