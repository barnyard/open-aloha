/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia.msml;

import noNamespace.MsmlDocument;
import noNamespace.MsmlDocument.Msml.Dialogend;
import noNamespace.MsmlDocument.Msml.Dialogstart;
import noNamespace.MsmlDocument.Msml.Dialogstart.Dtmf;
import noNamespace.MsmlDocument.Msml.Dialogstart.Dtmfgen;
import noNamespace.MsmlDocument.Msml.Dialogstart.Play;
import noNamespace.MsmlDocument.Msml.Dialogstart.Record;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.media.DtmfCollectCommand;
import com.bt.aloha.media.DtmfLengthPattern;
import com.bt.aloha.media.DtmfMinMaxRetPattern;
import com.bt.aloha.media.DtmfPattern;
import com.bt.aloha.media.PromptAndRecordCommand;
import com.bt.aloha.media.convedia.msml.model.MsmlAnnouncementRequest;
import com.bt.aloha.media.convedia.msml.model.MsmlCancelMediaRequest;
import com.bt.aloha.media.convedia.msml.model.MsmlDtmfGenerationRequest;
import com.bt.aloha.media.convedia.msml.model.MsmlPromptAndCollectDigitsRequest;
import com.bt.aloha.media.convedia.msml.model.MsmlPromptAndRecordRequest;
import com.bt.aloha.media.convedia.msml.model.MsmlRequest;
import com.convedia.moml.ext.BooleanType;

public class MsmlRequestParser extends MsmlParserBase {
	private static final int SEVEN = 7;
	private static Log log = LogFactory.getLog(MsmlRequestParser.class);

	public MsmlRequestParser() {
	}

	public MsmlRequest parse(String xml) {
		MsmlDocument doc = super.preProcess(xml);
		try {
			Dialogend dialogend = doc.getMsml().getDialogendArray(0);
			if (dialogend != null) {
				String id = dialogend.getId();
				log.debug(String.format("dialog end id: %s", id));
				return processCancelMediaRequest(id.substring(id.indexOf("dialog:")+SEVEN));
			}
		} catch(IndexOutOfBoundsException e) {
			log.debug("No dialogend element in document, continuing with parsing");
		}

		Dialogstart dialogstart = doc.getMsml().getDialogstartArray(0);
		if (null == dialogstart)
			throw new MsmlParseException("dialogstart element not found in document");

		String commandId = dialogstart.getId();
		String target = dialogstart.getTarget();
		log.debug(String.format("Parsing msml request for command %s, target %s", commandId, target));

		if (commandId.startsWith(MsmlAnnouncementRequest.PREFIX))
			return processAnnouncementRequest(target, commandId, dialogstart);
		if (commandId.startsWith(MsmlPromptAndCollectDigitsRequest.PREFIX))
			return processPromptAndCollectDigitsRequest(target, commandId, dialogstart);
		if (commandId.startsWith(MsmlDtmfGenerationRequest.PREFIX))
			return processDtmfGenerationRequest(target, commandId, dialogstart.getDtmfgenArray(0));
        if (commandId.startsWith(MsmlPromptAndRecordRequest.PREFIX))
            return processPromptAndRecordRequest(target, commandId, dialogstart);

		throw new MsmlParseException("Unknown media command:\n" + doc);
	}

	protected MsmlRequest processCancelMediaRequest(String id) {
		return new MsmlCancelMediaRequest(id, "");
	}

	protected MsmlAnnouncementRequest processAnnouncementRequest(String target, String commandId, Dialogstart dialogstart) {
		Play play = dialogstart.getPlayArray(0);
		return new MsmlAnnouncementRequest(target, commandId, play.getAudioArray(0).getUri(), BooleanType.TRUE.equals(play.getBarge()), BooleanType.TRUE.equals(play.getCleardb()));
	}

	protected MsmlPromptAndCollectDigitsRequest processPromptAndCollectDigitsRequest(String target, String commandId, Dialogstart dialogstart) {
		Play play = dialogstart.getPlayArray(0);
		Dtmf dtmf = dialogstart.getDtmfArray(0);
		DtmfPattern pattern = DtmfCollectCommand.parseStringPattern(dtmf.getPattern().getDigits());

		DtmfCollectCommand dtmfCollectCommand;
		if(pattern instanceof DtmfLengthPattern)
			dtmfCollectCommand = new DtmfCollectCommand(play.getAudioArray(0).getUri(),
					BooleanType.TRUE.equals(play.getBarge()),
					BooleanType.TRUE.equals(play.getCleardb()),
					Integer.parseInt(dtmf.getFdt().substring(0,dtmf.getFdt().length() - 1)),
					Integer.parseInt(dtmf.getIdt().substring(0,dtmf.getIdt().length() - 1)),
					Integer.parseInt(dtmf.getEdt().substring(0,dtmf.getEdt().length() - 1)),
					((DtmfLengthPattern)pattern).getLength());
		else
			dtmfCollectCommand = new DtmfCollectCommand(play.getAudioArray(0).getUri(),
					BooleanType.TRUE.equals(play.getBarge()),
					BooleanType.TRUE.equals(play.getCleardb()),
					Integer.parseInt(dtmf.getFdt().substring(0,dtmf.getFdt().length() - 1)),
					Integer.parseInt(dtmf.getIdt().substring(0,dtmf.getIdt().length() - 1)),
					Integer.parseInt(dtmf.getEdt().substring(0,dtmf.getEdt().length() - 1)),
					((DtmfMinMaxRetPattern)pattern).getMinDigits(),
					((DtmfMinMaxRetPattern)pattern).getMaxDigits(),
					((DtmfMinMaxRetPattern)pattern).getReturnKey());

		return new MsmlPromptAndCollectDigitsRequest(target, commandId, dtmfCollectCommand);
	}

    private String removeSeconds(String in) {
        if (in.endsWith("s")) return in.substring(0,in.length()-1);
        return in;
    }


    protected MsmlPromptAndRecordRequest processPromptAndRecordRequest(String target, String commandId, Dialogstart dialogstart) {
        // assume only one Play and Record stanza
        Record record = dialogstart.getRecordArray(0);
        Play play = dialogstart.getPlayArray(0);
        return new MsmlPromptAndRecordRequest(target, dialogstart.getId(),
                new PromptAndRecordCommand(play.getAudioArray(0).getUri(),
                        Boolean.getBoolean(play.getBarge().toString()),
                        record.getDest(),
                        record.isSetAppend(),
                        record.getFormat().toString(),
                        Integer.parseInt(removeSeconds(record.getMaxtime())),
                        Integer.parseInt(removeSeconds(record.getPreSpeech())),
                        Integer.parseInt(removeSeconds(record.getPostSpeech())),
                        record.getTermkey() != null && record.getTermkey().length() > 0 ? record.getTermkey().charAt(0) : null)
        );
    }

    protected MsmlDtmfGenerationRequest processDtmfGenerationRequest(String target, String commandId, Dtmfgen dtmfgen) {
		return new MsmlDtmfGenerationRequest(target, commandId, dtmfgen.getDigits());
	}
}
