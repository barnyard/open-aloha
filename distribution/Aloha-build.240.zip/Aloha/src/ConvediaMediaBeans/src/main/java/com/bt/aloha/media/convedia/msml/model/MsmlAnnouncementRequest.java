/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia.msml.model;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import noNamespace.MomlNamelistDatatype;
import noNamespace.MsmlDocument;
import noNamespace.MsmlDocument.Msml.Dialogstart;
import noNamespace.MsmlDocument.Msml.Dialogstart.Play;
import noNamespace.MsmlDocument.Msml.Dialogstart.Play.Audio;
import noNamespace.MsmlDocument.Msml.Dialogstart.Play.Playexit;
import noNamespace.MsmlDocument.Msml.Dialogstart.Play.Playexit.Send;

import com.bt.aloha.util.MessageDigestHelper;
import com.convedia.moml.ext.BooleanType;


public class MsmlAnnouncementRequest extends MsmlRequest {
	public static final String PREFIX = "ANNC";
	public static final int DEFAULT_ITERATIONS = 1;
	public static final int DEFAULT_INTERVAL = 0;
	private String audioFileUri;
	private boolean allowBarge;
	private boolean clearBuffer;
	private int iterations;
	private int interval;
	private MsmlApplicationEventType msmlApplicationEventType;

	public MsmlAnnouncementRequest(String aTargetAddress, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer) {
		this(aTargetAddress, PREFIX + MessageDigestHelper.generateDigest(), aAudioFileUri, aAllowBarge, aClearBuffer, DEFAULT_ITERATIONS, DEFAULT_INTERVAL, MsmlApplicationEventType.PLAY_COMMAND_COMPLETE);
	}

	public MsmlAnnouncementRequest(String aTargetAddress, String aCommandId, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer) {
		this(aTargetAddress, aCommandId, aAudioFileUri, aAllowBarge, aClearBuffer, DEFAULT_ITERATIONS, DEFAULT_INTERVAL, MsmlApplicationEventType.PLAY_COMMAND_COMPLETE);
	}

	public MsmlAnnouncementRequest(String aTargetAddress, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer, int aIterations) {
		this(aTargetAddress, PREFIX + MessageDigestHelper.generateDigest(), aAudioFileUri, aAllowBarge, aClearBuffer, aIterations, DEFAULT_INTERVAL, MsmlApplicationEventType.PLAY_COMMAND_COMPLETE);
	}

	public MsmlAnnouncementRequest(String aTargetAddress, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer, int aIterations, int aInterval) {
		this(aTargetAddress, PREFIX + MessageDigestHelper.generateDigest(), aAudioFileUri, aAllowBarge, aClearBuffer, aIterations, aInterval, MsmlApplicationEventType.PLAY_COMMAND_COMPLETE);
	}

	public MsmlAnnouncementRequest(String aTargetAddress, String aCommandId, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer, int aIterations) {
		this(aTargetAddress, aCommandId, aAudioFileUri, aAllowBarge, aClearBuffer, aIterations, DEFAULT_INTERVAL, MsmlApplicationEventType.PLAY_COMMAND_COMPLETE);
	}

	public MsmlAnnouncementRequest(String aTargetAddress, String aCommandId, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer, int aIterations, int aInterval) {
		this(aTargetAddress, aCommandId, aAudioFileUri, aAllowBarge, aClearBuffer, aIterations, aInterval, MsmlApplicationEventType.PLAY_COMMAND_COMPLETE);
	}

	public MsmlAnnouncementRequest(String aTargetAddress, String aCommandId, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer, MsmlApplicationEventType aEventType) {
		this(aTargetAddress, aCommandId, aAudioFileUri, aAllowBarge, aClearBuffer, DEFAULT_ITERATIONS, DEFAULT_INTERVAL, aEventType);
	}

	protected MsmlAnnouncementRequest(String aTargetAddress, String aCommandId, String aAudioFileUri, boolean aAllowBarge, boolean aClearBuffer, int aIterations, int aInterval, MsmlApplicationEventType aEventType) {
		super(aCommandId, aTargetAddress);

		if(aTargetAddress == null)
			throw new IllegalArgumentException("Target address for msml command must be specified");
		if(aAudioFileUri == null)
			throw new IllegalArgumentException("Audio uri for msml command must be specified");
		if(aIterations < -1 || aIterations == 0)
			throw new IllegalArgumentException(String.format("Unsupported number of playback iterations %d", aIterations));
		if(aInterval < 0)
			throw new IllegalArgumentException(String.format("Unsupported interval %d", aInterval));

		this.audioFileUri = aAudioFileUri;
		this.allowBarge = aAllowBarge;
		this.clearBuffer = aClearBuffer;
		this.iterations = aIterations;
		this.interval = aInterval;
		this.msmlApplicationEventType = aEventType;
	}

	public boolean isAllowBarge() {
		return allowBarge;
	}

	public String getAudioFileUri() {
		return audioFileUri;
	}

	public boolean isClearBuffer() {
		return clearBuffer;
	}

	public int getIterations() {
		return iterations;
	}

	public int getInterval() {
		return interval;
	}

	@Override
	public String getXml() {
		MsmlDocument doc = MsmlDocument.Factory.newInstance();
		Dialogstart dialogStart = super.createDialogstart(doc, getTargetAddress());

		Play play = dialogStart.addNewPlay();
		play.setBarge(BooleanType.Enum.forString(Boolean.valueOf(allowBarge).toString()));
		play.setCleardb(BooleanType.Enum.forString(Boolean.valueOf(clearBuffer).toString()));
		if (iterations != DEFAULT_ITERATIONS)
			play.setIterations(Integer.toString(iterations));
		if (interval != DEFAULT_INTERVAL)
			play.setInterval(String.format("%dms", interval));

		Audio audio = play.addNewAudio();
		audio.setUri(audioFileUri);

		Playexit playexit = play.addNewPlayexit();
		Send send = playexit.addNewSend();
		send.setTarget(SOURCE);
		send.setEvent(msmlApplicationEventType.value());
		List<MomlNamelistDatatype.Item.Enum> l = new ArrayList<MomlNamelistDatatype.Item.Enum>();
		l.add(MomlNamelistDatatype.Item.PLAY_END);
		l.add(MomlNamelistDatatype.Item.PLAY_AMT);
		send.setNamelist(l);

		Map<String,String> map = new Hashtable<String,String>();
		map.put(CVD_NS, CVD_PREFIX);

		return XML_PREFIX + doc.xmlText(super.createXmlOptions(map));
	}
}
