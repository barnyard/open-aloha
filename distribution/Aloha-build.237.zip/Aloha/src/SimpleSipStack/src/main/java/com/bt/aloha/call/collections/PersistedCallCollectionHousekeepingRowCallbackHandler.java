/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call.collections;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.jdbc.core.RowCallbackHandler;

import com.bt.aloha.call.state.CallInfo;
import com.bt.aloha.util.ConcurrentUpdateBlock;
import com.bt.aloha.util.ConcurrentUpdateManager;
import com.bt.aloha.util.HousekeeperAware;

// class to prepare calls for house keeping

public class PersistedCallCollectionHousekeepingRowCallbackHandler implements RowCallbackHandler, ApplicationContextAware {
    private Log log = LogFactory.getLog(this.getClass());
    private ApplicationContext applicationContext;
    private CallCollection callCollection;
    private ConcurrentUpdateManager concurrentUpdateManager;

    public PersistedCallCollectionHousekeepingRowCallbackHandler() {}

	public void processRow(ResultSet resultSet) throws SQLException {
    	String callId = null;
		try {
    		callId = resultSet.getString("callId");
        	String beanName = resultSet.getString("simpleSipBeanId");
        	log.info(String.format("Housekeeping: preparing call %s for being housekept by %s", callId, beanName));
        	HousekeeperAware creatorBean = (HousekeeperAware) applicationContext.getBean(beanName);
    		creatorBean.killHousekeeperCandidate(callId);
    	} catch (Throwable t) {
    		log.error(String.format("Unable to kill housekeeper candidate %s...will still remove from collection next housekeep", callId), t);
    	} finally {
    		final String localCallId = callId;
    		//force housekeeping next time for that object
    		ConcurrentUpdateBlock concurrentUpdateBlock = new ConcurrentUpdateBlock() {
				public void execute() {
					if (null == localCallId) return;
					log.info(String.format("Housekeeping: setting housekeepForced flag to true in info %s", localCallId));
					CallInfo callInfo = callCollection.get(localCallId);
					callInfo.setHousekeepForced(true);
					callCollection.replace(callInfo);
				}
				public String getResourceId() {
					return localCallId;
				}
			};
			concurrentUpdateManager.executeConcurrentUpdate(concurrentUpdateBlock);
    	}
	}

	public void setApplicationContext(ApplicationContext anApplicationContext) {
		this.applicationContext = anApplicationContext;
	}

	public void setCallCollection(CallCollection aCallCollection) {
		this.callCollection = aCallCollection;
	}

	public void setConcurrentUpdateManager(ConcurrentUpdateManager aConcurrentUpdateManager) {
		this.concurrentUpdateManager = aConcurrentUpdateManager;
	}
}
