/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia.conference;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.easymock.classextension.EasyMock;
import org.junit.Before;
import org.junit.Test;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bt.aloha.collections.memory.InMemoryHousekeepingCollectionImpl;
import com.bt.aloha.media.conference.collections.ConferenceCollection;
import com.bt.aloha.media.conference.collections.ConferenceCollectionImpl;
import com.bt.aloha.media.conference.state.ConferenceInfo;
import com.bt.aloha.media.conference.state.ConferenceState;
import com.bt.aloha.media.conference.state.ConferenceTerminationCause;

public class MaxConferenceDurationTerminationTest {

	private final static int FIVE_MINUTES_IN_MILLISECONDS = 300000;
	private final static int TWO_MINUTES = 2;
	private ConferenceInfo conferenceInfoInPast;
	private ConferenceInfo conferenceInfoInFuture;
	private ConferenceInfo conferenceInfoNoMaxDuration;
	private ConferenceCollection conferenceCollection;
	private MaxConferenceDurationTermination maxConferenceDurationTermination;
	private Log log = LogFactory.getLog(this.getClass());
    private boolean endConferenceCalled = false;
    private boolean terminateCalled = false;

	@Before
	public void setup(){
		maxConferenceDurationTermination = new MaxConferenceDurationTermination();
		conferenceCollection = new ConferenceCollectionImpl(new InMemoryHousekeepingCollectionImpl<ConferenceInfo>());
		conferenceInfoInPast = new ConferenceInfo("conferenceBean", "a:1", 5, TWO_MINUTES);
		long startTime = System.currentTimeMillis() - FIVE_MINUTES_IN_MILLISECONDS;
		log.debug(String.format("TEST: start time: %s", startTime));
		if (!conferenceInfoInPast.setStartTime(startTime))
			throw new RuntimeException("couldn't set time in the past for some reason");
		conferenceInfoInPast.updateConferenceState(ConferenceState.Active);

		conferenceInfoInFuture = new ConferenceInfo("conferenceBean", "a:1", 5, TWO_MINUTES);
		conferenceInfoInFuture.updateConferenceState(ConferenceState.Active);
		
		conferenceInfoNoMaxDuration = new ConferenceInfo("conferenceBean", "a:1", 5, 0);
		conferenceInfoNoMaxDuration.updateConferenceState(ConferenceState.Active);
		
		endConferenceCalled = false;
	    terminateCalled = false;
	}

	// create a conference that should have already been terminated and initalise the termination class
	// this should go through the collection and terminate any conferences that should have expired.
	@Test
	public void testInitializeWithTermination(){
		//setup
		conferenceCollection.add(conferenceInfoInPast);
		maxConferenceDurationTermination.setConferenceCollection(conferenceCollection);
		ConferenceBean conferenceBean = EasyMock.createMock(ConferenceBean.class);
		conferenceBean.endConference(conferenceInfoInPast.getId(), ConferenceTerminationCause.MaximumDurationExceeded);
		EasyMock.replay(conferenceBean);
		maxConferenceDurationTermination.setConferenceBean(conferenceBean);
		ThreadPoolTaskExecutor te = new ThreadPoolTaskExecutor();
		te.initialize();
		maxConferenceDurationTermination.setTaskExecutor(te);
		
		//act
		maxConferenceDurationTermination.runTask();
		try { Thread.sleep(500); } catch (InterruptedException e) { e.printStackTrace(); } // allow time for thread to run
		
		//assert
		EasyMock.verify(conferenceBean);
	}

	// create a conference that should be terminated in the future, assert that the call isn't removed
	// from the conference collection
	@Test
	public void testInitialiseWithoutTermination(){
		// setup
        terminateCalled = false;
		conferenceCollection.add(conferenceInfoInFuture);
		maxConferenceDurationTermination.setConferenceCollection(conferenceCollection);
		ConferenceBean conferenceBean = EasyMock.createMock(ConferenceBean.class);
		EasyMock.replay(conferenceBean);
		maxConferenceDurationTermination.setConferenceBean(conferenceBean);
		final String callId = conferenceInfoInFuture.getId();

		MaxConferenceDurationScheduler maxConferenceDurationScheduler = new MaxConferenceDurationScheduler(){
			public void cancelTerminateConference(ConferenceInfo conferenceInfo) {
			    // do nothing
			}

			public void terminateConferenceAfterMaxDuration(ConferenceInfo conferenceInfo, ConferenceBean conferenceBean) {
                terminateCalled = true;
			    if (conferenceInfo.getId() != callId)
			        throw new RuntimeException("unexpected call id");
			}
		};
		maxConferenceDurationTermination.setMaxConferenceDurationScheduler(maxConferenceDurationScheduler);
		
		//act
		maxConferenceDurationTermination.initialize();
		
		//assert
        EasyMock.verify(conferenceBean);
		assertTrue(terminateCalled);
	}

	// when a call has no max duration set, treat as infinite and do not terminate
	@Test
	public void testInitialiseWithNoLimit(){
		// setup
		conferenceCollection.add(conferenceInfoNoMaxDuration);
		maxConferenceDurationTermination.setConferenceCollection(conferenceCollection);
		ConferenceBean conferenceBean = new ConferenceBeanImpl(){
			@Override
			public void endConference(String conferenceId, ConferenceTerminationCause terminationCause) {
				endConferenceCalled = true;
			}
		};
		maxConferenceDurationTermination.setConferenceBean(conferenceBean);
		MaxConferenceDurationScheduler maxConferenceDurationScheduler = new MaxConferenceDurationScheduler(){
			public void cancelTerminateConference(ConferenceInfo conferenceInfo) {
			    // do nothing
			}

			public void terminateConferenceAfterMaxDuration(ConferenceInfo conferenceInfo, ConferenceBean conferenceBean) {
                terminateCalled = true;
			}
		};
		maxConferenceDurationTermination.setMaxConferenceDurationScheduler(maxConferenceDurationScheduler);

		// act
		maxConferenceDurationTermination.initialize();
		
		// assert
		assertFalse(terminateCalled);
		assertFalse(endConferenceCalled);
	}
	
    // ensure that we deal with any exceptions thrown by the conference bean
    @Test
    public void testInitializeConferenceBeanException(){
        //setup
        endConferenceCalled = false;
        conferenceCollection.add(conferenceInfoInPast);
        maxConferenceDurationTermination.setConferenceCollection(conferenceCollection);
        ConferenceBean conferenceBean = new ConferenceBeanImpl() {

            @Override
            public void endConference(String conferenceId, ConferenceTerminationCause terminationCause) {
                endConferenceCalled = true;
                throw new IllegalArgumentException("no call found");
            }

        };
        maxConferenceDurationTermination.setConferenceBean(conferenceBean);
        
        //act
        maxConferenceDurationTermination.initialize();
        
        //assert
        assertTrue(endConferenceCalled);
    }

    // ensure that we deal with any exceptions thrown by the termination scheduler
    @Test
    public void testInitialiseSchedulerException(){
        // setup
        terminateCalled = false;
        conferenceCollection.add(conferenceInfoInFuture);
        maxConferenceDurationTermination.setConferenceCollection(conferenceCollection);
        ConferenceBean conferenceBean = EasyMock.createMock(ConferenceBean.class);
        EasyMock.replay(conferenceBean);
        maxConferenceDurationTermination.setConferenceBean(conferenceBean);

        MaxConferenceDurationScheduler maxConferenceDurationScheduler = new MaxConferenceDurationScheduler(){
            public void cancelTerminateConference(ConferenceInfo conferenceInfo) {
                // do nothing
            }

            public void terminateConferenceAfterMaxDuration(ConferenceInfo conferenceInfo, ConferenceBean conferenceBean) {
                terminateCalled = true;
                throw new RuntimeException("unexpected call id");
            }
        };
        maxConferenceDurationTermination.setMaxConferenceDurationScheduler(maxConferenceDurationScheduler);

        //act
        maxConferenceDurationTermination.initialize();
        
        //assert
        EasyMock.verify(conferenceBean);
        assertTrue(terminateCalled);
    }
}
