/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia.conference;

import java.util.concurrent.ConcurrentMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.task.TaskExecutor;

import com.bt.aloha.media.conference.collections.ConferenceCollection;
import com.bt.aloha.media.conference.state.ConferenceInfo;
import com.bt.aloha.media.conference.state.ConferenceState;
import com.bt.aloha.media.conference.state.ConferenceTerminationCause;

public class MaxConferenceDurationTermination {

	private static final long MINUTE_TO_MILLISECONDS = 60000;
	private ConferenceBean conferenceBean;
	private ConferenceCollection conferenceCollection;
	private MaxConferenceDurationScheduler maxConferenceDurationScheduler;
	private Log log = LogFactory.getLog(this.getClass());
	private TaskExecutor taskExecutor;

	public MaxConferenceDurationTermination() {}

	public void runTask() {
		log.debug("runTask()");
		this.taskExecutor.execute(new Runnable() {
			public void run() {
				initialize();
			}
		});
	}
	
    public void initialize() {
    	log.debug("initialize()");
    	//TODO: replace getAll()
	    ConcurrentMap<String, ConferenceInfo> allConferenceCalls = 	conferenceCollection.getAll();
	    log.debug(String.format("Initialising with %s conference calls", allConferenceCalls.size()));
	    for (ConferenceInfo conferenceInfo : allConferenceCalls.values())
	    	if (conferenceInfo.getConferenceState().equals(ConferenceState.Active) && conferenceInfo.getMaxDurationInMinutes() > 0)
	    		setTerminationTime(conferenceInfo);
	}

	private void setTerminationTime(ConferenceInfo conferenceInfo) {
		long timeToTerminate = conferenceInfo.getStartTime() + (conferenceInfo.getMaxDurationInMinutes() * MINUTE_TO_MILLISECONDS);
		log.debug(String.format("ConferenceId: %s, start time: %s, max duration: %s, time to terminate: %s, current time: %s",
				conferenceInfo.getId(), conferenceInfo.getStartTime(), conferenceInfo.getMaxDurationInMinutes() * MINUTE_TO_MILLISECONDS, timeToTerminate, System.currentTimeMillis()));
		if (timeToTerminate <= System.currentTimeMillis()){
			log.debug(String.format("Request termination on conferenceId: %s", conferenceInfo.getId()));
			try {
			    conferenceBean.endConference(conferenceInfo.getId(), ConferenceTerminationCause.MaximumDurationExceeded);
            } catch (Throwable t) {
                log.warn("Error ending conference", t);
            }
		} else {
			log.debug(String.format("Set termination time to %s on conferenceId %s", timeToTerminate, conferenceInfo.getId()));
            try {
                maxConferenceDurationScheduler.terminateConferenceAfterMaxDuration(conferenceInfo, conferenceBean);
            } catch (Throwable t) {
                log.warn("Error scheduling end of conference", t);
            }
		}
	}

	public void setConferenceCollection(ConferenceCollection aConferenceCollection){
		this.conferenceCollection = aConferenceCollection;
	}

	public void setConferenceBean(ConferenceBean aConferenceBean){
		this.conferenceBean = aConferenceBean;
	}

	public void setMaxConferenceDurationScheduler(MaxConferenceDurationScheduler aMaxConferenceDurationScheduler){
		this.maxConferenceDurationScheduler = aMaxConferenceDurationScheduler;
	}

	public void setTaskExecutor(TaskExecutor aTaskExecutor) {
		this.taskExecutor = aTaskExecutor;
	}
}
