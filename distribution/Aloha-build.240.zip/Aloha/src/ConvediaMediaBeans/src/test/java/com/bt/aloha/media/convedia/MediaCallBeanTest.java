/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/**
 * (c) British Telecommunications plc, 2007, All Rights Reserved
 */
package com.bt.aloha.media.convedia;

import org.easymock.EasyMock;
import org.junit.Test;

import com.bt.aloha.media.MediaCallBean;
import com.bt.aloha.media.MediaCallLegBean;


public class MediaCallBeanTest {
	/**
	 * Tests that when we set the media dialog bean that the media call bean is added to the list of listeners
	 */
	@Test
	public void addMediaCallBeanAsListenerWhenSettingMediaDialog() {
		// setup
		MediaCallBeanImpl mediaCallBean = new MediaCallBeanImpl();
		MediaCallLegBean dialogBean = EasyMock.createMock(MediaCallLegBean.class);
		dialogBean.addMediaCallLegListener(mediaCallBean);
		EasyMock.replay(dialogBean);
		
		// act
		mediaCallBean.setMediaCallLegBean(dialogBean);
		
		// assert
		EasyMock.verify(dialogBean);
	}
	
	/**
	 * tests that when we set the media dialog bean that's already been set we remove ourselves first
	 */
	@Test
	public void removeMediaCallBeanAsListenerWhenResettingMediaDialog() {
		// setup
		MediaCallBeanImpl mediaCallBean = new MediaCallBeanImpl();
		MediaCallLegBean dialogBean = EasyMock.createMock(MediaCallLegBean.class);
		dialogBean.addMediaCallLegListener(mediaCallBean);
		dialogBean.removeMediaCallLegListener(mediaCallBean);
		EasyMock.replay(dialogBean);
		MediaCallLegBean anotherDialogBean = EasyMock.createMock(MediaCallLegBean.class);
		anotherDialogBean.addMediaCallLegListener(mediaCallBean);
		EasyMock.replay(anotherDialogBean);
		mediaCallBean.setMediaCallLegBean(dialogBean);
		
		// act
		mediaCallBean.setMediaCallLegBean(anotherDialogBean);
		
		// assert
		EasyMock.verify(dialogBean);
		EasyMock.verify(anotherDialogBean);
	}
	
	// test that you cannot add a null listener
	@Test(expected=IllegalArgumentException.class)
	public void addNullListener() {
		// act
		MediaCallBean mediaCallBean = new MediaCallBeanImpl();
		mediaCallBean.addMediaCallListener(null);
		
		// assert - exception
	}
	
	// test that you cannot remove a null listener
	@Test(expected=IllegalArgumentException.class)
	public void removeNullListener() {
		// act
		MediaCallBean mediaCallBean = new MediaCallBeanImpl();
		mediaCallBean.removeMediaCallListener(null);
		
		// assert - exception
	}
}
