/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse;

import javax.sip.message.Response;

import com.bt.aloha.phones.Controller;
import com.bt.aloha.phones.SipulatorPhone;

public class CallControlFixture extends SimpleSipStackBaseFixture {
	private String mySipAddress;
	private String remoteSipAddress;
	private String remoteSipProxy;
	private String myPhoneName;
	private String realm;
	private String username;
	private String password;
	protected long waitTimeout = 0;
	
	static{
		FixtureApplicationContexts.getInstance().startMockphonesApplicationContext();
	}
	
	public CallControlFixture(){
		super(FixtureApplicationContexts.getInstance().startApplicationContext());
	}
	
	public void mySipAddress(String value) {
		mySipAddress = value.replaceAll("localhost", SipulatorPhone.lookupIpAddress(null));
	}
	
	public void realm(String r) {
		this.realm = r;
	}

	public void username(String u) {
		this.username = u;
	}

	public void password(String p) {
		this.password = p;
	}
	
	public void remoteSipAddress(String value) {
		remoteSipAddress = getAddressAndPort(value);
	}
	
	public void remoteSipProxy(String value) {
		remoteSipProxy = getAddressAndPort(value);
	}
	
	public void waitTimeout(String value) throws Exception {
		waitTimeout = Long.parseLong(value);
	}
	
	public void createMyPhone() throws Exception {
		mySipAddress = checkAddress(mySipAddress);
	}
	
	public boolean sendInvite() throws Exception {
		return Controller.getInstance().initiateCall(myPhoneName, realm, username, password);
	}
	
	public boolean sendInviteOkAck() throws Exception {
		return Controller.getInstance().sendInviteOkAck(myPhoneName);
	}
	
	public boolean respondToBye() throws Exception {
		return Controller.getInstance().respondToBye(myPhoneName);
	}
	
	public boolean waitResponseServiceUnavailable() throws Exception {
		return Controller.getInstance().waitResponse(myPhoneName, Response.SERVICE_UNAVAILABLE, waitTimeout);
	}
	
	public boolean waitResponseTemporarilyUnavailable() throws Exception {
		return Controller.getInstance().waitResponse(myPhoneName, Response.TEMPORARILY_UNAVAILABLE, waitTimeout);
	}
	
	public boolean waitResponseBusy() throws Exception {
		return Controller.getInstance().waitResponse(myPhoneName, Response.BUSY_HERE, waitTimeout);
	}
	
	public boolean waitResponseError() throws Exception {
		return Controller.getInstance().waitResponse(myPhoneName, Response.SERVER_INTERNAL_ERROR, waitTimeout);
	}
	
	public boolean waitResponseOk() throws Exception {
		return Controller.getInstance().waitResponse(myPhoneName, Response.OK, waitTimeout);
	}
	
	public boolean waitAnswerOk() throws Exception {
		return Controller.getInstance().waitAnswer(myPhoneName, Response.OK, waitTimeout);
	}
	
	public boolean waitResponseRinging() throws Exception {
		return Controller.getInstance().waitResponse(myPhoneName, Response.RINGING, waitTimeout);
	}
	
	public boolean waitForBye() throws Exception {
		return Controller.getInstance().waitForBye(myPhoneName, waitTimeout);
	}
	
	public boolean waitForInvite() throws Exception {
		return Controller.getInstance().waitForInvite(myPhoneName, waitTimeout);
	}
	
    protected String checkAddress(String inputAddress) throws Exception {
        String address = inputAddress.trim();
        
        if (!address.toLowerCase().startsWith("mock:"))
            return address.trim().replaceAll("localhost", SipulatorPhone.lookupIpAddress(ipAddressPattern));

        myPhoneName = getMockPhoneName(address);

        Controller.getInstance().createPhone(myPhoneName, ipAddressPattern, remoteSipAddress, remoteSipProxy);
        return "sip:" + address.substring("mock:".length()).replaceAll("localhost", SipulatorPhone.lookupIpAddress(ipAddressPattern)) + (SipulatorPhone.port() == 5060 ? "" : (":" + SipulatorPhone.port()));
    }
    
    protected String getMockPhoneName(String address) {
        if (!address.toLowerCase().startsWith("mock:"))
        	return null;
        
        int at = address.indexOf("@");
        return address.substring("mock:".length(), at);
    }

    public String tearDown() throws Exception {
        try {
        	Controller.getInstance().stopPhone(myPhoneName);
        } catch (Exception e) {
            return e.getMessage();
        }
        Thread.sleep(1000);
        return "OK";
    }
}
