/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse.siploadbalancer;

import gov.nist.javax.sip.stack.HopImpl;

import java.util.ListIterator;

import javax.sip.SipException;
import javax.sip.SipStack;
import javax.sip.address.Address;
import javax.sip.address.Hop;
import javax.sip.address.SipURI;
import javax.sip.address.URI;
import javax.sip.header.CallIdHeader;
import javax.sip.message.Request;

import org.apache.log4j.Logger;

public class Router implements javax.sip.address.Router {
	private Logger log = Logger.getLogger(getClass());

	// NIST stack currently can't instantiate a javax.sip.address.Router impl through a default constructor
	public Router(SipStack sipStack, String defaultRoute) {
	}
	
	public Hop getNextHop(Request request) throws SipException {
		log.debug(String.format("Get next hop called for sip call id: %s", ((CallIdHeader)request.getHeader(CallIdHeader.NAME)).getCallId()));
		Address hostAddress = RoundRobinHostManager.getInstance().lookupHost();
		URI hostURI = hostAddress.getURI();
		if(hostURI instanceof SipURI) {
			SipURI hostSipURI = (SipURI)hostURI;
			return new HopImpl(hostSipURI.getHost(), hostSipURI.getPort(), "udp");
		}
		throw new RuntimeException("Don't know how to route request " + request.getRequestURI());
	}

	public ListIterator<?> getNextHops(Request request) {
		throw new RuntimeException("Deprecated method getNextHops not implemented");
	}

	public Hop getOutboundProxy() {
		throw new RuntimeException("Method getOutboundProxy not implemented");
	}

}
