/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call.state;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.callleg.AutoTerminateAction;
import com.bt.aloha.dialog.state.ImmutableDialogInfo;

public class InitiateMediaNegotiationCommand extends MediaNegotiationCommandBase {
	private static final Log LOG = LogFactory.getLog(InitiateMediaNegotiationCommand.class);
	private String callId;
	private AutoTerminateAction autoTerminateAction;
	
	public InitiateMediaNegotiationCommand(ImmutableDialogInfo aDialogInfo, AutoTerminateAction aAutoTerminateAction, String aCallId, CallLegConnectionState aCallLegConnectionState) {
		super(aDialogInfo, aCallLegConnectionState);
		this.callId = aCallId;
		this.autoTerminateAction = aAutoTerminateAction;
	}
	
	public void execute() {
		LOG.debug(String.format("Initiating media negotiation for call %s via call leg %s with state %s", callId, getDialogInfo().getId(), getCallLegConnectionState()));
		if (getDialogInfo().isInbound() && !getCallLegConnectionState().equals(CallLegConnectionState.Completed)) {
			throw new IllegalStateException(String.format("Cannot initiate media negotiation via non-confirmed (%s) inbound dialog %s", getCallLegConnectionState(), getDialogInfo().getId()));
		}

		if (getCallLegConnectionState().equals(CallLegConnectionState.Completed)) {
			reinviteCallLeg(getDialogInfo(), null, autoTerminateAction, callId);
		} else if (getCallLegConnectionState().equals(CallLegConnectionState.Pending)) {
			getOutboundCallLegBean().connectCallLeg(getDialogInfo().getId(), autoTerminateAction, callId, null, false);
		}
	}

	public void updateCallInfo(CallInfo callInfo) {
		MediaNegotiationMethod mediaNegotiationMethod = null;
		if (getCallLegConnectionState().equals(CallLegConnectionState.Completed)) {
			mediaNegotiationMethod = MediaNegotiationMethod.ReinviteRequest;
		} else if (getCallLegConnectionState().equals(CallLegConnectionState.Pending)) {
			mediaNegotiationMethod = getDialogInfo().isInbound() ? MediaNegotiationMethod.InitialOkResponse : MediaNegotiationMethod.InitialInviteRequest;
		}
		
		callInfo.setMediaNegotiationState(MediaNegotiationState.Initiated);
		callInfo.setMediaNegotiationMethod(mediaNegotiationMethod);
		LOG.debug(String.format("Updated call info for call %s, set media negotiation state to %s and method to %s", callInfo.getId(), callInfo.getMediaNegotiationState(), callInfo.getMediaNegotiationMethod()));
	}
}
