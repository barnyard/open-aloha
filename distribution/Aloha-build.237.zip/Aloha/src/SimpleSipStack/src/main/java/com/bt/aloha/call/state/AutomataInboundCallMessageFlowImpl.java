/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call.state;

import javax.sdp.MediaDescription;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.dialog.state.ImmutableDialogInfo;

public class AutomataInboundCallMessageFlowImpl extends InboundCallMessageFlowImpl {
	private static final Log LOG = LogFactory.getLog(AutomataInboundCallMessageFlowImpl.class);
	
	public AutomataInboundCallMessageFlowImpl() {
	}
	
	@Override
	public MediaNegotiationCommand initializeCall(ImmutableDialogInfo firstDialogInfo, ImmutableDialogInfo secondDialogInfo, ReadOnlyCallInfo callInfo, MediaDescription offerMediaDescription) {
		return initializeCall(firstDialogInfo, secondDialogInfo, callInfo, offerMediaDescription, false);
	}
	
	@Override
	protected MediaNegotiationCommand initializeCall(ImmutableDialogInfo firstDialogInfo, ImmutableDialogInfo secondDialogInfo, ReadOnlyCallInfo callInfo, MediaDescription offerMediaDescription, boolean suppressProxy) {
		LOG.debug(String.format("Initializing call %s using sip flow %s", callInfo.getId(), this.getClass().getSimpleName()));
		ImmutableDialogInfo inboundDialogInfo = firstDialogInfo.isInbound() ? firstDialogInfo : secondDialogInfo;
		ImmutableDialogInfo outboundDialogInfo = firstDialogInfo.isInbound() ? secondDialogInfo : firstDialogInfo;
    	
    	CallLegConnectionState inboundConnectionState = callInfo.getCallLegConnectionState(inboundDialogInfo.getId());
    	CallLegConnectionState outboundConnectionState = callInfo.getCallLegConnectionState(outboundDialogInfo.getId());
    	
    	MediaNegotiationCommand command = null;
    	if (outboundConnectionState.equals(CallLegConnectionState.Pending) || outboundConnectionState.equals(CallLegConnectionState.Completed)) {
	    	if (inboundConnectionState.equals(CallLegConnectionState.Pending)) {
	    		if (inboundDialogInfo.isSdpInInitialInvite()) {
	    			if (!suppressProxy) {
	    				command = new ProxyMediaOfferCommand(outboundDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), offerMediaDescription, outboundConnectionState, true);
	    			}
	    		} else {
	    			command = new ConnectAndHoldCommand(inboundDialogInfo, inboundConnectionState, callInfo.getAutoTerminate(), null);
	    		}
			} else if (inboundConnectionState.equals(CallLegConnectionState.Completed)) {
				command = new InitiateMediaNegotiationCommand(inboundDialogInfo, callInfo.getAutoTerminate(), callInfo.getId(), inboundConnectionState);   			
	    	}
		} else if (outboundConnectionState.equals(CallLegConnectionState.InProgress) && inboundConnectionState.equals(CallLegConnectionState.Pending)) {
			command = new ConnectAndHoldCommand(inboundDialogInfo, inboundConnectionState, callInfo.getAutoTerminate(), offerMediaDescription);
		}
    	return command;
	}
}
