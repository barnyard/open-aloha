/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse.siploadbalancer;

import gov.nist.javax.sip.header.Via;

import java.text.ParseException;
import java.util.Vector;

import javax.sip.DialogTerminatedEvent;
import javax.sip.IOExceptionEvent;
import javax.sip.RequestEvent;
import javax.sip.ResponseEvent;
import javax.sip.SipException;
import javax.sip.SipListener;
import javax.sip.TimeoutEvent;
import javax.sip.TransactionTerminatedEvent;
import javax.sip.address.Address;
import javax.sip.header.ViaHeader;
import javax.sip.message.Request;
import javax.sip.message.Response;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.phones.SipulatorPhone;
import com.bt.aloha.stack.SimpleSipStack;
import com.bt.aloha.stack.StackException;

public class SipLoadBalancer implements SipListener {
	private Log log = LogFactory.getLog(getClass());
	private SimpleSipStack simpleSipStack;
	
	public SipLoadBalancer() {}
	
	public void setSimpleSipStack(SimpleSipStack simpleSipStack) {
		this.simpleSipStack = simpleSipStack;		
	}
	
	private String parseHostAddress(String address) {
		if (address == null)
			return null;
		
		String name = "";
		if (address.startsWith("sip:"))
			name = address.substring(0, address.indexOf(":")+1);
		
		String ipAddress = address.substring(name.length(), address.lastIndexOf(":"));
		String port = address.substring(address.lastIndexOf(":"));
		return name + SipulatorPhone.lookupIpAddress(ipAddress) + port;
	}
	
	public void setHosts(String hostList) throws ParseException {
		Vector<Address> hosts = new Vector<Address>();
		String[] list = hostList.split(",");
		for (String host : list) {
			Address addr = simpleSipStack.getAddressFactory().createAddress(parseHostAddress(host));
			log.info("Adding host " + addr.getURI() + " to hosts list for load balancer");
			hosts.add(addr);
		}
		RoundRobinHostManager.getInstance().setHosts(hosts);
	}

	public void removeHost(String address)  throws ParseException {
		Address addr = simpleSipStack.getAddressFactory().createAddress(parseHostAddress(address));
		RoundRobinHostManager.getInstance().removeHost(addr);
	}

	public void addHost(String address)  throws ParseException {
		Address addr = simpleSipStack.getAddressFactory().createAddress(parseHostAddress(address));
		RoundRobinHostManager.getInstance().addHost(addr);
	}

	public void processRequest(RequestEvent requestEvent) {		
		Request request = requestEvent.getRequest();
		log.info("SipLoadBalancer: request received");
		log.info(request.toString());
		proxyRequest(request);
	}
	
	private void proxyRequest(Request request) {
		try {
			simpleSipStack.getSipProvider().sendRequest(request);
		} catch (SipException e) {
			throw new StackException("Error proxying request",e);
		}
	}
	
	private void proxyResponse(Response response) {
		try {
			simpleSipStack.getSipProvider().sendResponse(response);
		} catch (SipException e) {
			throw new StackException("Error proxying request",e);
		}
	}
	
	public void processResponse(ResponseEvent responseEvent) {
		Response response = responseEvent.getResponse();		
		log.info("Response received");
		log.info(response.toString());
		ViaHeader viaHeader =(ViaHeader)response.getHeader(ViaHeader.NAME);
		// Strip off RPORT if destined for me
		if(viaHeader != null && Integer.toString(simpleSipStack.getPort()).equals(viaHeader.getParameter(Via.RPORT)))
			viaHeader.removeParameter(Via.RPORT);
		proxyResponse(response);
	}

	public void processTimeout(TimeoutEvent timeOutEvent) {
		log.warn("TimeoutEvent received: " + timeOutEvent.toString());
	}

	public void processIOException(IOExceptionEvent ioExceptionEvent) {
		log.warn("IOExceptionEvent received: " + ioExceptionEvent.toString());
	}

	public void processTransactionTerminated(TransactionTerminatedEvent transactionTerminatedEvent) {
		log.debug("TransactionTerminatedEvent received: " + transactionTerminatedEvent);
	}

	public void processDialogTerminated(DialogTerminatedEvent dialogTerminatedEvent) {
		String sipUri = dialogTerminatedEvent.getDialog().getLocalParty().getURI().toString();
		log.debug("DialogTerminatedEvent received for " + sipUri);		
	}
}
