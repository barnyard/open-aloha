/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.call.collections;

import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import com.bt.aloha.call.state.CallInfo;
import com.bt.aloha.call.state.CallState;
import com.bt.aloha.dao.CallInfoDao;
import com.bt.aloha.util.CollectionHelper;

public class PersistedCallCollectionImpl implements CallCollection {

    private CallInfoDao callInfoDao;
	private PersistedCallCollectionHousekeepingRowCallbackHandler rowCallbackHandler;
	private long maxTimeToLive;
	private ConcurrentMap<String, Map<String, Object>> transients = new ConcurrentHashMap<String, Map<String, Object>>();

    public PersistedCallCollectionImpl(CallInfoDao aCallInfoDao) {
        this.callInfoDao = aCallInfoDao;
    }

    private CallInfo readTransients(CallInfo result) {
    	if (null == result) return null;
    	if (transients.containsKey(result.getId()))
    		result.setTransients(transients.get(result.getId()));
    	return result;
    }

    public CallInfo getCurrentCallForCallLeg(String callLegId) {
        CallInfo result = callInfoDao.findCallForDialogId(callLegId);
        return readTransients(result);
    }

    public CallInfo getCurrentCallForCallLeg(String callLegId, String callIdToIgnore) {
        CallInfo result = callInfoDao.findCallForDialogId(callLegId, callIdToIgnore);
        return readTransients(result);
    }

    public void add(CallInfo callInfo) {
    	if (null == callInfo)
    		throw new IllegalArgumentException("callInfo cannot be null");
    	transients.put(callInfo.getId(), callInfo.getTransients());
        callInfoDao.create(callInfo);
    }

    public void destroy() {
    	CollectionHelper.destroy(transients, this.getClass().getSimpleName());
    }

    public CallInfo get(String id) {
        CallInfo result = callInfoDao.read(id);
        return readTransients(result);
    }

    public ConcurrentMap<String, CallInfo> getAll() {
    	ConcurrentMap<String, CallInfo> result = callInfoDao.getAll();

    	for (CallInfo callInfo: result.values())
    		readTransients(callInfo);
    	
    	return result;
    }

    public void init() {
    	throw new UnsupportedOperationException();
    }

    public void remove(String id) {
    	transients.remove(id);
        callInfoDao.delete(id);
    }

    public void replace(CallInfo callInfo) {
    	transients.put(callInfo.getId(), callInfo.getTransients());
        callInfoDao.update(callInfo);
    }

    public int size() {
        return callInfoDao.size();
    }

    public int sizeTransients() {
    	if(transients!=null)
    		return transients.size();
    	return 0;
    }

    public void housekeep() {
    	List<String> transientsToBeCleaned = callInfoDao.findByHousekeeperFlags(Calendar.getInstance().getTimeInMillis() - maxTimeToLive);
    	callInfoDao.deleteByHousekeeperFlags(Calendar.getInstance().getTimeInMillis() - maxTimeToLive);
    	for(String callId: transientsToBeCleaned){
    		transients.remove(callId);
    	}
    	callInfoDao.updateByHousekeeperFlags(Calendar.getInstance().getTimeInMillis() - maxTimeToLive, this.rowCallbackHandler);
    }

    public void setMaxTimeToLive(long aMaxTimeToLive) {
        this.maxTimeToLive = aMaxTimeToLive;
    }

	public void setPersistedCallCollectionHousekeepingRowCallbackHandler(PersistedCallCollectionHousekeepingRowCallbackHandler aRowCallbackHandler) {
		this.rowCallbackHandler = aRowCallbackHandler;
		this.rowCallbackHandler.setCallCollection(this);
	}

    public ConcurrentMap<String, CallInfo> getAllConnectedCallsWithMaxDuration() {
    	ConcurrentMap<String, CallInfo> result = callInfoDao.findConnectedMaxDurationCalls();

    	for (CallInfo callInfo: result.values())
    		readTransients(callInfo);
    	
    	return result;
    }

	protected ConcurrentMap<String, Map<String, Object>> getTransients() {
		return transients;
	}

	public long getNumberOfConnectingCalls() {
		return callInfoDao.countByCallState(CallState.Connecting, transients.keySet());
	}
}
