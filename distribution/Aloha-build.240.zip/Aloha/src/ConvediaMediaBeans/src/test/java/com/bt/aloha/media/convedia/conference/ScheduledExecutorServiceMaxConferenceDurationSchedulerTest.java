/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/**
 * (c) British Telecommunications plc, 2007, All Rights Reserved
 */
package com.bt.aloha.media.convedia.conference;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

import com.bt.aloha.media.conference.state.ConferenceInfo;



public class ScheduledExecutorServiceMaxConferenceDurationSchedulerTest {
	private static final String UNCHECKED = "unchecked";
	
	private ConferenceInfo conferenceInfo;

	@Before
	public void before() {
		conferenceInfo = new ConferenceInfo("conferenceBean", "a:1", 5, 5);
	}

	/**
	 * Tests that conference info is scheduled correctly
	 */
	@SuppressWarnings(UNCHECKED)
	@Test
	public void scheduleConferenceForTermination() {
		// setup
		ScheduledExecutorServiceMaxConferenceDurationScheduler scheduler = new ScheduledExecutorServiceMaxConferenceDurationScheduler();
		ScheduledFuture future = EasyMock.createMock(ScheduledFuture.class);
		EasyMock.replay(future);
		ScheduledExecutorService executorService = EasyMock.createMock(ScheduledExecutorService.class);
		EasyMock.expect(executorService.schedule(EasyMock.isA(TerminateConferenceTask.class), EasyMock.eq((long)300), EasyMock.eq(TimeUnit.SECONDS))).andReturn(future);
		EasyMock.replay(executorService);
		scheduler.setScheduledExecutorService(executorService);

		// act
		scheduler.terminateConferenceAfterMaxDuration(conferenceInfo, null);

		// assert
		EasyMock.verify(future);
		EasyMock.verify(executorService);
	}

	/**
	 * Tests that cancel terminate task is cancelled correctly
	 */
	@SuppressWarnings(UNCHECKED)
	@Test
	public void cancelScheduledConferenceTermination() {
		// setup
		ScheduledExecutorServiceMaxConferenceDurationScheduler scheduler = new ScheduledExecutorServiceMaxConferenceDurationScheduler();
		ScheduledFuture future = EasyMock.createMock(ScheduledFuture.class);
		EasyMock.expect(future.cancel(false)).andReturn(true);
		EasyMock.replay(future);
		ScheduledExecutorService executorService = EasyMock.createMock(ScheduledExecutorService.class);
		EasyMock.expect(executorService.schedule(EasyMock.isA(TerminateConferenceTask.class), EasyMock.eq((long)300), EasyMock.eq(TimeUnit.SECONDS))).andReturn(future);
		EasyMock.replay(executorService);
		scheduler.setScheduledExecutorService(executorService);
		scheduler.terminateConferenceAfterMaxDuration(conferenceInfo, null);

		// act
		scheduler.cancelTerminateConference(conferenceInfo);

		// assert
		EasyMock.verify(future);
		EasyMock.verify(executorService);

	}

	/**
	 * Tests that cancel terminate task doesnt throw exceptions even if it wasn't scheduled
	 */
	@Test
	public void cancelScheduledConferenceTerminationShouldntBarfWhenItWasntScheduled() {
		// setup
		ScheduledExecutorServiceMaxConferenceDurationScheduler scheduler = new ScheduledExecutorServiceMaxConferenceDurationScheduler();
		ScheduledFuture<?> future = EasyMock.createMock(ScheduledFuture.class);
		EasyMock.replay(future);
		ScheduledExecutorService executorService = EasyMock.createMock(ScheduledExecutorService.class);
		EasyMock.replay(executorService);
		scheduler.setScheduledExecutorService(executorService);

		// act
		scheduler.cancelTerminateConference(conferenceInfo);

		// assert
		EasyMock.verify(future);
		EasyMock.verify(executorService);
	}

//	Tests that scheduling a conference termination task cancels any previous timers before scheduling a new one
	@SuppressWarnings(UNCHECKED)
	@Test
	public void scheduleConferenceTerminationShouldCancelEarlierSchedulerIfExistsBeforeRescheduling() {
		// setup
		ScheduledExecutorServiceMaxConferenceDurationScheduler scheduler = new ScheduledExecutorServiceMaxConferenceDurationScheduler();
		ScheduledFuture future = EasyMock.createMock(ScheduledFuture.class);
		EasyMock.expect(future.cancel(false)).andReturn(false);
		EasyMock.replay(future);
		ScheduledExecutorService executorService = EasyMock.createMock(ScheduledExecutorService.class);
		EasyMock.expect(executorService.schedule(EasyMock.isA(TerminateConferenceTask.class), EasyMock.eq((long)300), EasyMock.eq(TimeUnit.SECONDS))).andReturn(future).times(2);
		EasyMock.replay(executorService);
		scheduler.setScheduledExecutorService(executorService);
		scheduler.terminateConferenceAfterMaxDuration(conferenceInfo, null);

		// act
		scheduler.terminateConferenceAfterMaxDuration(conferenceInfo, null);

		// assert
		EasyMock.verify(future);
		EasyMock.verify(executorService);
	}
}
