/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.media.convedia.conference;

import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.media.conference.state.ConferenceInfo;

public class ScheduledExecutorServiceMaxConferenceDurationScheduler implements MaxConferenceDurationScheduler {
	private static final int NUMBER_OF_SECONDS_IN_ONE_MINUTE = 60;
	private Log log = LogFactory.getLog(this.getClass());
	private ScheduledExecutorService executorService;

	public ScheduledExecutorServiceMaxConferenceDurationScheduler() {
		executorService = null;
	}

	public void terminateConferenceAfterMaxDuration(ConferenceInfo conferenceInfo, ConferenceBean conferenceBean) {
		cancelTerminateConference(conferenceInfo);
		log.debug(String.format("Scheduling conference %s to be terminated after %s min", conferenceInfo.getId(), conferenceInfo.getMaxDurationInMinutes()));
		ScheduledFuture<?> future = this.executorService.schedule(new TerminateConferenceTask(conferenceInfo.getId(), conferenceBean), conferenceInfo.getMaxDurationInMinutes() * NUMBER_OF_SECONDS_IN_ONE_MINUTE, TimeUnit.SECONDS);
		conferenceInfo.setFuture(future);
	}

	public void setScheduledExecutorService(ScheduledExecutorService theExecutorService) {
		this.executorService = theExecutorService;
	}

	public void cancelTerminateConference(ConferenceInfo conferenceInfo) {
		log.debug(String.format("Canceling terminating scheduler for conference %s", conferenceInfo.getId()));
		ScheduledFuture<?> future = conferenceInfo.getFuture();
		if (future != null)
			log.debug(String.format("Cancel succeeded: %s", future.cancel(false)));
	}
}
