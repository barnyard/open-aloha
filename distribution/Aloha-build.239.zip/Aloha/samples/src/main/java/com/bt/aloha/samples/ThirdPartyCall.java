/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.samples;

import java.net.URI;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bt.aloha.call.CallBean;
import com.bt.aloha.call.CallListener;
import com.bt.aloha.call.event.CallConnectedEvent;
import com.bt.aloha.call.event.CallConnectionFailedEvent;
import com.bt.aloha.call.event.CallDisconnectedEvent;
import com.bt.aloha.call.event.CallTerminatedEvent;
import com.bt.aloha.call.event.CallTerminationFailedEvent;
import com.bt.aloha.callleg.OutboundCallLegBean;

/**
 * ThirdPartyCall with the addition of being a "listener" to events related to calls
 */
public class ThirdPartyCall implements CallListener {

    private ClassPathXmlApplicationContext applicationContext;
    private String callId;

    public void makeCall(String caller, String callee) throws Exception {
        // load Spring
        applicationContext = new ClassPathXmlApplicationContext("com/bt/aloha/samples/ThirdPartyCall.ApplicationContext.xml");

        // get required beans
        OutboundCallLegBean outboundCallLegBean = (OutboundCallLegBean)applicationContext.getBean("outboundCallLegBean");
        CallBean callBean = (CallBean)applicationContext.getBean("callBean");

        // make this class a listener to call events
        callBean.addCallListener(this);

        // create two call legs
        String callLegId1 = outboundCallLegBean.createCallLeg(URI.create(callee), URI.create(caller));
        String callLegId2 = outboundCallLegBean.createCallLeg(URI.create(caller), URI.create(callee));

        // join the call legs
        this.callId = callBean.joinCallLegs(callLegId1, callLegId2);
        System.out.println(this.callId);
    }

    public void onCallConnected(CallConnectedEvent arg0) {
        System.out.println(arg0.getClass().getSimpleName());
        if (arg0.getCallId().equals(this.callId))
            applicationContext.destroy();
    }

    public void onCallConnectionFailed(CallConnectionFailedEvent arg0) {
        System.out.println(arg0.getClass().getSimpleName());
        applicationContext.destroy();
    }

    public void onCallDisconnected(CallDisconnectedEvent arg0) {
        System.out.println(arg0.getClass().getSimpleName());
        applicationContext.destroy();
    }

    public void onCallTerminated(CallTerminatedEvent arg0) {
        System.out.println(arg0.getClass().getSimpleName());
        applicationContext.destroy();
    }

    public void onCallTerminationFailed(CallTerminationFailedEvent arg0) {
        System.out.println(arg0.getClass().getSimpleName());
        applicationContext.destroy();
    }

    public static void main(String[] args) throws Exception {
        new ThirdPartyCall().makeCall("sip:XXXXXXXXXXX@10.238.67.22", "sip:XXXXXXXXXXX@10.238.67.22");
    }
}
