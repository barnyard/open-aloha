-- connect as springringuser
drop table persistencysipstack_dialoginfo;
drop table persistencysipstack_conferenceinfo;
drop table persistencysipstack_callinfo;
