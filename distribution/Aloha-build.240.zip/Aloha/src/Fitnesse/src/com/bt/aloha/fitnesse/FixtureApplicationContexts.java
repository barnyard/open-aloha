/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
package com.bt.aloha.fitnesse;

import java.util.concurrent.ConcurrentMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.bt.aloha.call.ScheduledExecutorServiceMaxCallDurationScheduler;
import com.bt.aloha.call.collections.CallCollection;
import com.bt.aloha.call.state.CallInfo;
import com.bt.aloha.media.conference.collections.ConferenceCollection;
import com.bt.aloha.media.conference.state.ConferenceInfo;
import com.bt.aloha.media.convedia.conference.ScheduledExecutorServiceMaxConferenceDurationScheduler;

public class FixtureApplicationContexts {
	private ClassPathXmlApplicationContext applicationContext = null;
	private ClassPathXmlApplicationContext mockphonesapplicationContext = null;
	private ClassPathXmlApplicationContext mediaApplicationContext = null;
	private ClassPathXmlApplicationContext secondApplicationContext = null;
	private ClassPathXmlApplicationContext sipLoadBalancerApplicationContext = null;
	private ClassPathXmlApplicationContext inboundApplicationContext = null;
	private ClassPathXmlApplicationContext persistencyApplicationContext = null;
	private static final Log log = LogFactory.getLog(FixtureApplicationContexts.class);
	private static final FixtureApplicationContexts instance = new FixtureApplicationContexts();

	private FixtureApplicationContexts(){

	}

	public static FixtureApplicationContexts getInstance(){
		return instance;
	}

    public void destroyPersistencyApplicationContext(){
        if (null != persistencyApplicationContext)
            persistencyApplicationContext.destroy();
    }

	public ClassPathXmlApplicationContext startApplicationContext() {
		return startApplicationContext(false);
	}

	public ClassPathXmlApplicationContext startApplicationContext(
			boolean destroyFirst) {
		applicationContext = startCustomApplicationContext(applicationContext,
				"testApplicationContext.xml", destroyFirst, 0);
		return applicationContext;
	}

	public ClassPathXmlApplicationContext startMockphonesApplicationContext(){
		return startMockphonesApplicationContext(false);
	}

	public ClassPathXmlApplicationContext startMockphonesApplicationContext(
			boolean destroyFirst) {
		mockphonesapplicationContext = startCustomApplicationContext(
				mockphonesapplicationContext,
				"mockphonesApplicationContext.xml", destroyFirst, 0);
		return mockphonesapplicationContext;
	}

	public ClassPathXmlApplicationContext startMediaApplicationContext(){
		return startMediaApplicationContext(false);
	}

	public ClassPathXmlApplicationContext startMediaApplicationContext(
			boolean destroyFirst) {
		mediaApplicationContext = startCustomApplicationContext(
				mediaApplicationContext, "mediaApplicationContext.xml",
				destroyFirst, 0);
		return mediaApplicationContext;
	}

	public ClassPathXmlApplicationContext startSecondApplicationContext(){
		return startSecondApplicationContext(false);
	}

	public ClassPathXmlApplicationContext startSecondApplicationContext(
			boolean destroyFirst) {
		secondApplicationContext = startCustomApplicationContext(
				secondApplicationContext, "secondTestApplicationContext.xml",
				destroyFirst, 0);
		return secondApplicationContext;
	}

	public ClassPathXmlApplicationContext startSipLoadBalancerApplicationContext(){
		return startSipLoadBalancerApplicationContext(false);
	}

	public ClassPathXmlApplicationContext startSipLoadBalancerApplicationContext(
			boolean destroyFirst) {
		sipLoadBalancerApplicationContext = startCustomApplicationContext(
				sipLoadBalancerApplicationContext,
				"sipLoadBalancerApplicationContext.xml", destroyFirst, 0);
		return sipLoadBalancerApplicationContext;
	}

	public ClassPathXmlApplicationContext startInboundApplicationContext(){
		return startInboundApplicationContext(false);
	}

	public ClassPathXmlApplicationContext startInboundApplicationContext(
			boolean destroyFirst) {
		inboundApplicationContext = startCustomApplicationContext(
				inboundApplicationContext, "inboundTestApplicationContext.xml",
				destroyFirst, 0);
		return inboundApplicationContext;
	}

	public ClassPathXmlApplicationContext startPersistencyApplicationContext(){
		return startPersistencyApplicationContext(false, 0);
	}

	public ClassPathXmlApplicationContext startPersistencyApplicationContext(
			boolean destroyFirst, int restartAfter) {
		persistencyApplicationContext = startCustomApplicationContext(
				persistencyApplicationContext,
				"persistencyApplicationContext.xml", destroyFirst, restartAfter);
		return persistencyApplicationContext;
	}

	public ClassPathXmlApplicationContext startCustomApplicationContext(
			ClassPathXmlApplicationContext applicationContext,
			String resourceName, boolean destroyFirst, int restartAfter) {
		if (applicationContext == null){
			String distroyMessage = (destroyFirst ? "(ignoring 'distroyFirst' flag)":"");
			log.debug(String.format("creating new application context from '%s' %s", resourceName, distroyMessage));
			return new ClassPathXmlApplicationContext(resourceName);
		}
		if (destroyFirst) {
			log.debug(String.format("distroying and re-creating new application context from '%s'", resourceName));
			cancelTerminationTimers(applicationContext);
			applicationContext.destroy();
			try {
				Thread.sleep(restartAfter);
			} catch (InterruptedException e) {
				log.warn("Unable to sleep while jvm is down, interrupted");
			}
			ClassPathXmlApplicationContext result = new ClassPathXmlApplicationContext(resourceName);
			log.debug("returning");
			return result;
		}
		log.debug(String.format("using an already created application context from '%s'", resourceName));
		return applicationContext;
	}

	private void cancelTerminationTimers(ClassPathXmlApplicationContext applicationContext) {
		CallCollection callCollection = (CallCollection)applicationContext.getBean("callCollection");
		ConferenceCollection conferenceCollection = (ConferenceCollection)applicationContext.getBean("conferenceCollection");
		ScheduledExecutorServiceMaxCallDurationScheduler callTerminator = (ScheduledExecutorServiceMaxCallDurationScheduler)applicationContext.getBean("maxCallDurationScheduler");
		ScheduledExecutorServiceMaxConferenceDurationScheduler conferenceTerminator = (ScheduledExecutorServiceMaxConferenceDurationScheduler)applicationContext.getBean("maxConferenceDurationScheduler");
		
		ConcurrentMap<String, CallInfo> calls = callCollection.getAll();
		for (CallInfo callInfo : calls.values())
			callTerminator.cancelTerminateCall(callInfo);
		ConcurrentMap<String, ConferenceInfo> conferences = conferenceCollection.getAll();
		for (ConferenceInfo conferenceInfo : conferences.values())
			conferenceTerminator.cancelTerminateConference(conferenceInfo);
	}
}
