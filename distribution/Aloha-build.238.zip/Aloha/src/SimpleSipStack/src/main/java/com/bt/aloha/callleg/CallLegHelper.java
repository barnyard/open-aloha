/*
Copyright (c) 2008, British Telecommunications plc
 	
All rights reserved.
 	
Redistribution, copy, create derivative works, distribute, issue, perform,
assisting performance, broadcast, adapt, possess, display, make, sell, offer
to sell and import in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:
 	
* Redistributions of source code must retain the above copyright notice, this
list of conditions and the following disclaimer. * Redistributions in binary
form must reproduce the above copyright notice, this list of conditions and
the following disclaimer in the documentation and/or other materials provided
with the distribution. * Neither the name of the British Telecommunications
plc nor the names of its contributors may be used to endorse or promote
products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY OR SATISFACTORY QUALITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
POSSIBILITY OF SUCH DAMAGE.
*/
/**
 * (c) British Telecommunications plc, 2007, All Rights Reserved
 */
package com.bt.aloha.callleg;

import javax.sdp.MediaDescription;
import javax.sip.message.Request;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.bt.aloha.dialog.DialogBeanHelper;
import com.bt.aloha.dialog.DialogConcurrentUpdateBlock;
import com.bt.aloha.dialog.collections.DialogCollection;
import com.bt.aloha.dialog.state.DialogInfo;
import com.bt.aloha.dialog.state.DialogState;
import com.bt.aloha.dialog.state.ReadOnlyDialogInfo;
import com.bt.aloha.dialog.state.TerminationCause;
import com.bt.aloha.dialog.state.TerminationMethod;
import com.bt.aloha.util.ConcurrentUpdateBlock;
import com.bt.aloha.util.ConcurrentUpdateManager;

public abstract class CallLegHelper extends DialogBeanHelper {
    private static final Log LOG = LogFactory.getLog(CallLegHelper.class);

    public CallLegHelper() {
        super();
    }

       protected abstract DialogCollection getDialogCollection();
    protected abstract ConcurrentUpdateManager getConcurrentUpdateManager();
    protected abstract void endNonConfirmedDialog(ReadOnlyDialogInfo dialogInfo, TerminationMethod previousTerminationMethod);
    protected abstract void acceptReceivedMediaOffer(final String dialogId, final MediaDescription mediaDescription, boolean offerInOkResponse, final boolean initialInviteTransactionCompleted);

    protected DialogBeanHelper getDialogBeanHelper() {
        return this;
    }

    public void terminateCallLeg(final String dialogId, final TerminationCause aDialogTerminationCause) {
        LOG.info(String.format("Terminating dialog %s with termination cause %s", dialogId, aDialogTerminationCause));
        ConcurrentUpdateBlock concurrentUpdateBlock = new DialogConcurrentUpdateBlock(getDialogBeanHelper()) {
            public void execute() {
                DialogInfo dialogInfo = getDialogCollection().get(dialogId);
                if(dialogInfo==null){
                    LOG.warn(String.format("Attempt to terminate dialog '%s' failed, as object not in collection", dialogId));
                    return;
                }
                DialogState dialogState = dialogInfo.getDialogState();
                dialogInfo.setTerminationCause(aDialogTerminationCause);
                if (DialogState.Created.equals(dialogState)) {
                    dialogInfo.setDialogState(DialogState.Terminated);
                    getDialogCollection().replace(dialogInfo);
                    LOG.info(String.format("Dialog %s terminated from state Created, no messages sent for this dialog", dialogId));
                    return;
                }

                TerminationMethod previousTerminationMethod = dialogInfo.setTerminationMethod(TerminationMethod.Terminate);
                if (previousTerminationMethod == null) {
                    LOG.info(String.format("Failed to terminate dialog %s - already cancelling or terminating", dialogInfo.getId()));
                    return;
                }

                if (DialogState.Confirmed.equals(dialogState)) {
                    assignSequenceNumber(dialogInfo, Request.BYE);
                    Request byeRequest = getDialogBeanHelper().createByeRequest(dialogInfo);
                    getDialogCollection().replace(dialogInfo);
                    getDialogBeanHelper().sendRequest(byeRequest);
                } else if (DialogState.Confirmed.ordinal() > dialogState.ordinal()) {
                    getDialogCollection().replace(dialogInfo);
                    endNonConfirmedDialog(dialogInfo, previousTerminationMethod);
                }
            }

            public String getResourceId() {
                return dialogId;
            }
        };
        getConcurrentUpdateManager().executeConcurrentUpdate(concurrentUpdateBlock);
    }

    public CallLegInformation getCallLegInformation(String callLegId) {
        if(callLegId == null)
            throw new IllegalArgumentException("Call leg identifier must be specified");

        ReadOnlyDialogInfo dialogInfo = getDialogCollection().get(callLegId);
        if(dialogInfo == null)
            throw new IllegalArgumentException(String.format("Unknown call leg identifier %s", callLegId));

        return new CallLegInformation(dialogInfo);
    }
}
